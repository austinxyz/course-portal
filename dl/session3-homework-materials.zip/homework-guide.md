# Session 3 作业指南

## 作业：写一个轻量版 `/market-daily`

### 目标
用 Claude Code 帮你从零建一个 skill，每天一行命令生成你自己的市场日报。

### 步骤

**Step 1：解压课程工具包**
下载 `stock-analysis-lite.zip` → 解压 → Claude Code Open Folder 打开

**Step 2：用 Claude Code 建 skill 文件**

在 Claude Code 对话框里输入：

```
请帮我建一个 /market-daily skill，功能如下：
- 用 yfinance 拉取今天 SPY、QQQ、VIX 的数据
- 生成一份每日市场简报，包含：大盘涨跌、VIX 情绪、今日关键点
- 保存为 outputs/market/YYYY-MM-DD.md

请创建：
1. scripts/market_daily.py（数据拉取脚本）
2. .claude/commands/market-daily.md（skill 定义）
```

**Step 3：测试**

```bash
python scripts/market_daily.py
```

确认数据正常后跑：
```
/market-daily
```

**Step 4：进阶（选做）**
在 prompt 里加上你自己持仓的 ticker，让日报包含你关注的个股状态。

### 提交
把生成的日报文件（`.md`）发到炒股兴趣群，或邮件发给 Austin。
不需要完美，能跑起来就算完成。
