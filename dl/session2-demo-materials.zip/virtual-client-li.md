# 李女士客户画像——备用稿

> 用途：Step 7 /wealth-client-qa 出错或 Skill 未就绪时，直接粘贴此内容到 output/li/，继续 Step 8 演示。

---

## 基本信息

| 字段 | 内容 |
|------|------|
| 姓名 | 李女士 |
| 年龄 | 35 岁 |
| 职业 | 湾区 startup 软件工程师 |
| 公司阶段 | Series B，刚入职 3 个月 |
| 收入 | 年薪 $18 万 + ISO options（5,000 股，行权价 $8） |
| 家庭 | 单身，无子女 |
| 账户 | 无旧公司 401K，无 IRA，无 529 |

---

## 最关心的问题

**ISO Early Exercise + AMT 风险**

ISO options 还没到 cliff（3 个月后满），想了解：
- 能不能 early exercise？（83(b) election）
- Early exercise 有什么税务风险？
- AMT 是什么？会不会触发？

---

## wiki 对应条目

| wiki 路径 | 对应问题 |
|-----------|---------|
| `wiki/tax/iso-options.md` | ISO 税务处理 |
| `wiki/tax/amt-basics.md` | AMT 计算与风险 |
| `wiki/tax/83b-election.md` | 83(b) election 操作 |

---

## 关键问题 + 答案要点

### Q：ISO early exercise 值得做吗？

**核心结论：** 如果公司前景好、行权价低，early exercise + 83(b) election 值得考虑，但要在入职 30 天内提交 83(b) election，否则窗口关闭。

**答案要点：**
1. **什么是 early exercise：** 在 vesting 前行权，买入股票，时钟从行权日开始计算 LTCG 持有期
2. **为什么要做：** 行权价 $8 时行权，未来以更高价格卖出的收益算 LTCG（税率更低）；不做的话，vest 时按普通收入税率征税
3. **AMT 风险：** 行权价（$8）与 FMV 的差价是 AMT 优先项。如果 FMV 已经远高于 $8，early exercise 可能触发 AMT，需要计算
4. **83(b) election：** 入职 30 天内邮寄给 IRS，否则机会永久失去
5. **明天可以做的事：**
   - 确认入职日期，计算 83(b) election 截止日（入职后第 30 天）
   - 向公司 HR 要 stock option agreement，确认 FMV（409A valuation）
   - 计算行权所需资金：5,000 股 × $8 = $40,000
