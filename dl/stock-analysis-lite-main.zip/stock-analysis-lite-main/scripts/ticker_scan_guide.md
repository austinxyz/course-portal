# ticker_scan.py — 数据层说明

## 为什么不直接在 Skill 里用 yfinance？

Claude Code Skill（`.claude/commands/*.md`）运行时是 LLM 在读文件、调工具——它**不能执行 Python**，也没有 Python 运行时。

yfinance 是 Python 库，必须由 Python 进程调用。所以流程是：

```
/ticker-scan
  └─ Step 1: bash → python scripts/ticker_scan.py MRVL MU ... --json
               └─ yfinance 拉数据，计算指标，输出 JSON
  └─ Step 2: LLM 读 JSON，做定性分析，输出报告
```

两层分离：**Python 管数字，LLM 管判断**。

---

## ticker_scan.py 封装了什么？

直接用 yfinance 有几个问题，脚本统一处理了：

| 问题 | yfinance 原始 | ticker_scan.py 做了什么 |
|------|-------------|----------------------|
| 字段名不稳定 | `.info` 有 200+ 字段，版本间变化 | 只提取需要的字段，做 null 兜底 |
| 营收要自己算 | `.quarterly_financials` 返回 DataFrame | 算好 YoY %、加速度、连续季度数 |
| OTC 判断复杂 | `exchange` 值多样（OTC/PNK/GREY/BTS…）| `_is_otc()` 统一判断，直接给 `is_otc: bool` |
| MA 要手算 | `.history()` 只给原始价格 | 算好 MA50/MA200，输出偏离百分比 |
| 并发慢 | 单线程串行，10 只股 ~60s | `ThreadPoolExecutor` 并发，~10s |
| 编码报错 | Windows 默认 cp1252，中文/特殊字符崩 | `sys.stdout.reconfigure(encoding="utf-8")` |

---

## 输出字段说明

```json
{
  "ticker": "MRVL",
  "exchange": "NMS",           // 交易所代码
  "is_otc": false,             // true = OTC，ticker-scan 会排除
  "market_cap_m": 44200.0,    // 市值（百万美元）
  "revenue_yoy_pct": 37.5,   // 最新季度营收 YoY %（null = 数据不足）
  "revenue_accel": true,      // 营收增速是否在加快
  "consecutive_growth_q": 4,  // 连续几个季度营收正增长
  "eps_trend": "improving",   // loss→profit / profit→loss / improving / declining / stable / unknown
  "eps_loss_narrow_pct": 42.3, // 仍亏损时的YoY亏损收窄%（本季度和去年同季度都亏损才输出；正数=亏损收窄）
  "inst_pct": 71.3,           // 机构持仓 %（null = 无数据）
  "ma50_pct": 4.2,            // 现价偏离 MA50 %（正数 = 在 MA50 上方；历史不足时省略该键）
  "ma150_pct": 9.8,           // 现价偏离 MA150 %（历史不足 150 天时省略该键）
  "ma200_pct": 18.7,          // 现价偏离 MA200 %（历史不足 200 天时省略该键）
  "ma200_trend": "up",        // MA200 vs 21 交易日前："up"/"down"/"flat"（历史不足 221 天时省略该键）
  "max_gap_up_pct": 14.2,      // 抓取窗口内最大单日跳空高开 %（scan=1年 / full=2年；财报 gap 信号）
  "price_bar_date": "2026-07-23", // 上述 ma*_pct/max_gap_up_pct 基于的「已确认」日线日期（scan/full 均输出）
  "latest_bar_missing": true,  // 仅当最近交易日日线在 yfinance 尚未补上时出现；出现时所有价格类字段落后一个交易日（scan/full 均输出）
  "live_price": 8.05,          // 仅 latest_bar_missing=true 时出现：实时/最近成交价，可能与已确认K线有较大偏离（scan/full 均输出）
  "live_price_source": "fast_info", // live_price 来源："fast_info" 或 "info"

  // ---- 以下字段仅 --mode full 输出（单股深度，各自缺数据省略）----
  "price": 8.42,              // 最新「已确认」日线收盘价（即 price_bar_date 那根K线；MA/ATR/trend_template 均基于同一根K线，口径一致）
  "atr14": 0.61, "atr_pct": 7.2,          // 14日ATR / 占现价%
  "vol_avg20_m": 3.1, "vol_ratio": 1.8,   // 20日均量(百万股) / 今日量比
  "high_52w": 12.4, "low_52w": 3.1,       // 52周高低
  "pct_from_52w_high": -32.1, "pct_above_52w_low": 171.6,
  "rs_score": 14.2, "rs_pass": true,      // RS加权收益差 vs SPY
  "trend_template": {"score": 6},          // SEPA 8条布尔+score
  "next_earnings_date": "2026-08-07", "earnings_in_days": 15,
  "short_pct_float": 12.3, "float_m": 45.2, "shares_out_m": 51.0,
  "cash_m": 88.5
}
```

`--benchmark` 额外输出一行市场环境（独立于个股行）：

```json
{
  "benchmark": true,
  "spy_vs_ma200_pct": 6.2,    // SPY 现价偏离 MA200 %
  "qqq_vs_ma200_pct": 8.1,    // QQQ 现价偏离 MA200 %
  "market_env": "bull"        // 两者均>0="bull"；均<0="bear"；否则"chop"
}
```

拉取失败的 ticker 输出 `{"ticker": "XXX", "error": "..."}`，其余字段省略。

---

## 用法

```bash
# 基本用法：传 ticker，人类可读输出
python scripts/ticker_scan.py MRVL MU QMCO

# JSON 模式：供 Skill/LLM 解析
python scripts/ticker_scan.py MRVL MU QMCO --json

# 单股验证
python scripts/ticker_scan.py LWLG --json

# 单股深度模式：ATR/52周/RS/趋势模板/财报日/筹码/现金
python scripts/ticker_scan.py LWLG --mode full --json

# 市场环境：SPY/QQQ vs MA200 → bull/chop/bear（可单独用，也可与 ticker 组合）
python scripts/ticker_scan.py --benchmark --json
python scripts/ticker_scan.py MRVL MU --benchmark --json
```

---

## 局限

- 数据来自 yfinance（Yahoo Finance），有时延（非实时），偶尔字段缺失
- `revenue_yoy_pct` 需要至少 5 个季度数据，新股/新上市可能为 null
- `inst_pct` 需要额外 HTTP 请求（较慢），小市值股可能无机构持仓数据
- 不含实时新闻、订单 backlog、机构 13F 变化——这些由 LLM + WebSearch 处理
- **日线数据延迟发布**：yfinance 偶尔整体延迟发布最近一个交易日的日线（观察到影响多只不相关ticker，非个股问题）。scan/full 两模式都输出 `price_bar_date`，缺最新K线时都输出 `latest_bar_missing=true` + `live_price` 兜底，而不是静默返回落后一天的数据。注意兜底只是「暴露信号」：此时 `ma*_pct`/`max_gap_up_pct`/`price` 等价格类字段仍基于 `price_bar_date` 那根K线，需对比 `live_price` 判断偏离是否影响结论
