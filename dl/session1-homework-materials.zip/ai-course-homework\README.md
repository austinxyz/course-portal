# Session 1 作业

作业分两部分：

---

## Part A — 自己跑一遍 Demo（不用交）

目录：`demo/`

把今天演示的 4-Agent 求职流水线自己跑一遍，感受整个过程。

**文件说明：**
- `starter-project/` — 上传到你的 Claude Cowork Project 的初始文件（简历 + 5C 方法论）
- `virtual-jd.md` / `virtual-jd-2.md` — 演示用的虚拟 JD，提前发邮件到你的演示 Gmail
- `test-run.md` — 完整演示脚本，按步骤跟着走

这部分不用提交，自己体验为主。

---

## Part B — 搭自己的流水线（要交）

指南：`homework-guide.md`

选一个你真实会用到的场景，设计 2–3 个 Agent，在 Cowork 里跑通，然后按指南说明发邮件提交。
