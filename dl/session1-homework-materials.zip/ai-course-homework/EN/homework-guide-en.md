# Session 1 Homework Guide: Build Your Own Pipeline in Cowork

> Not sure where to start? Follow this guide step by step.

**Goal:** Build a Cowork pipeline that's genuinely yours. Even two Agents counts — if it runs end to end, you're done.

---

## 📖 Step Zero: How to open these `.md` files (do this first if you're not sure)

The download is full of `.md` (Markdown) files — Notepad can open them, but the formatting is a mess. **We recommend Obsidian: free, good-looking, works on Mac and Windows:**

1. **Download and install**: go to [obsidian.md](https://obsidian.md) → click Download → pick your OS (Mac / Windows) and install it.
2. **Open the materials folder as a "vault"**: unzip the download first (you'll get an `ai-course-homework` folder). Open Obsidian → on the first screen click **"Open folder as vault"** → select that `ai-course-homework` folder → click through Trust / Confirm.
3. **Read the files**: every `.md` shows up in the left sidebar. Click any of them and the formatted content appears on the right.
4. **Switch between reading and editing**: the small icon in the top-right toggles Reading view and Editing view. Reading view is all you need to start.

> Quick alternatives: drag the `.md` into VS Code or Typora. Or just use Obsidian — install once and everything after that is easier.

---

# Part A — Run the class demo yourself with `follow-along-prompts` (nothing to submit)

> It's fine if you couldn't keep up in class. This part walks you through the full prompt list at home so you get the feel of it. **Work directly from `follow-along-prompts-en.md` — those are exactly the prompts I typed one by one in class, each tagged with "what this step does." Just copy them.**

1. **Open the list**: in Obsidian's left sidebar open `demo/follow-along-prompts-en.md` — every prompt used in the class demo is in there, in order, each with a one-line "what this step does." If you can't read `.md`, do Step Zero above first.
2. **Set up the Project**:
   - Create a new Cowork Project and upload `alex-chen-resume.md` and `5c-methodology.md` from `demo/starter-project/`.
   - Email the two JDs, `demo/virtual-jd.md` and `demo/virtual-jd-2.md`, to your own Gmail, **using the subject line written at the top of each file**.
   - Connect Gmail under Project Settings → Connectors.
3. **Set the approval mode**: leave it on **Manual** for Step 0 so you can see the permission prompts, then switch to **Auto** so the rest runs without interrupting you. (Don't use Skip.)
4. **Follow Part 1**: working from the "Part 1" section of `follow-along-prompts-en.md`, **paste each Agent's prompt one at a time** into Cowork (Agent 1→2→3→4), following the ① bare-bones → ② have AI improve it → ③ iterate markers.
5. **Run Part 2**: as scripted, open a new conversation and send `check new JD`, then watch all 4 Agents run in sequence.
6. **⚡ Saving quota on Pro ($20)**: stay on the default **Sonnet**, don't switch to Opus; **split it across two sessions** (Part 1 in one, Part 2 + weekly review in the next 5-hour window). See the quota tips in the download's `README.md`.
7. **Look at what you made**: when it's done, open the Project's `OUTPUTS/` and you'll find `jd-analysis.md`, `company-research.md`, `linkedin-outreach.md`, `pipeline-tracker.md` — a concrete feel for "files are the source of truth."

> This part is pure practice, nothing to submit. Once it feels natural, move on to Part B.

---

# Part B — Build a pipeline of your own (this one gets submitted)

## Step 1: Pick a scenario you'll actually use

It doesn't need to be perfect. Pick something **you'll run into this week**:

| Scenario | Trigger material | Connector you could wire in | What you want out |
|----------|-----------------|----------------------------|-------------------|
| Work reporting | Meeting notes / weekly task list | Google Drive / Notion | Weekly report / email draft |
| Email handling | Client emails you received | **Gmail** | Categorized summary + reply drafts |
| Market research | Competitor sites / product pages | — | Comparison table / briefing outline |
| Content creation | A one-line topic / reference articles | — | Outline + first draft |
| Job search | A JD | **Gmail** | Company research + outreach draft |
| Meeting follow-up | Calendar + meeting notes | **Google Calendar** | Action list + follow-up email |

---

## Step 2: Design 2–3 Agents

Each Agent does one thing, and one step's output is the next step's input:

```
Trigger material (email / document / something you paste)
    ↓
Agent 1: analyze / filter / distill
    ↓ output file
Agent 2: produce the deliverable (report / draft / table)
    ↓ output file
Agent 3 (optional): format / archive / track
```

### Prompt framework (copy it, replace what's in brackets)

```
You are a [role, e.g. content analyst / workplace writing consultant / business researcher].

Based on [input source, e.g. the email content in this conversation /
the project file xxx.md],
produce [specific deliverable, e.g. an analysis report / a weekly report draft /
a comparison table].

Requirements:
- [format requirement, e.g. structured list, under 300 words]
- [style requirement, e.g. concise, output in English]
- [must include, e.g. one clear recommended action]

Save the output to: OUTPUTS/[filename].md
```

### Example: work reporting (2 Agents chained)

**Agent 1 — Distill the key points**
```
You are a workplace writing consultant, skilled at pulling structured
information out of scattered notes.

From the following notes on this week's work, extract:
1. The three most important deliverables this week (one sentence each,
   with result metrics)
2. The main blockers you hit (1-2 items)
3. The single highest-priority thing for next week

Output format: three numbered lists, each item under 30 words.
Save the output to: OUTPUTS/weekly-summary.md

Input: {paste this week's work notes}
```

**Agent 2 — Generate the weekly report (reads Agent 1's output)**
```
You are a workplace writing consultant, skilled at turning structured
information into upward-reporting material.

Read OUTPUTS/weekly-summary.md and generate a weekly report for my direct manager.

Requirements:
- Format: title + 3 key points + 1 plan for next week, under 200 words total
- Tone: professional, concise, results-oriented
- Lead with outcomes; don't repeat the blockers

Save the output to: OUTPUTS/weekly-report.md
```

> Agent 1 distills, Agent 2 polishes. Splitting it into two steps keeps each one focused and makes the output far more consistent.

---

## Step 3: Do it in Cowork

1. **Create a Project**: upload your background files (resume, role description, personal info) as memory files
2. **Write your Project Instructions**: tell Claude who you are and which trigger phrase should run the pipeline
3. **Build up pipeline-prompts.md**: each time you finish an Agent's prompt, have Claude append it to `pipeline-prompts.md` in the Project (built as you go, finished automatically — no cleanup-and-upload afterwards)
4. **Connect a Connector (if you're using one)**: authorize Gmail / Google Drive etc. in Project Settings
5. **Trigger it**: send one sentence and watch the Agents run in sequence

---

## How to submit: three things in one email

**Send to:** austin.aicourse@gmail.com

**Use the template below — don't change the format, just fill in the brackets:**

---

**Subject line:**
```
Session 1 Homework - [Your Name]
```

**Body:**
```
[1. My Agent prompts]

[Paste the prompts you wrote, 2-3 blocks. No screenshots needed.]


[2. Output excerpt]

[Paste the first 100 words of the analysis report, or the full outreach draft]


[3. Reflection (200+ words)]

[What is Cowork actually good for? What you personally experienced.
Any format.]
```

---

> All three parts are required for the homework to count. Screenshots alone don't count. Keep the `[1.] [2.] [3.]` headings so submissions can be processed consistently.

---

## What if it isn't working?

- **The prompt isn't producing what you want**: just tell Claude "no, what I want is…", then update the revised version into `pipeline-prompts.md`
- **You don't know how to write the prompt**: ask Claude first — "I want an Agent that helps me [do what], the input is [what], the output is [what]. Write me the prompt."
- **Still stuck**: screenshot it and post in the group; we'll cover it in the next class Q&A.
