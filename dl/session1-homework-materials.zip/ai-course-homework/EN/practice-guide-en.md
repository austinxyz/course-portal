# Post-Class Practice Guide: Turn Session 1 Into Your Own Capability

Congratulations on finishing the first class! But **understanding ≠ being able to do it**. Real capability comes from walking through it yourself in Cowork. Five steps below — do them in order, and never skip the "write down what you learned" part. That's the soul of the whole method.

---

## Where do the materials come from? (download first, then start)

Before you begin, go back to the **S1 student portal page** (the page you came in from) and download two things:

1. **The course materials zip** — click "Download Course Materials (includes homework)" and **unzip it**. Inside you'll find `follow-along-prompts-en.md`, `starter-project/`, the two JDs, and `homework-guide-en.md` (**that one is the actual homework assignment**). You'll use all of these below.
2. **The course slides** — click "Download Session 1 Slides (PPTX)".

💡 In Step 0 below, the PPT that goes into `ppt/`, the `follow-along-prompts-en.md` that goes into `course-notes/`, and the assignment that goes into `homework-project/` (**that's `homework-guide-en.md` from the zip — just rename it `assignment.md` after you move it**) all come from those two downloads.

> Also: when you follow `follow-along-prompts-en.md` to run the class demo, it'll have you create **another** Cowork Project pointed at `starter-project`. That's a separate Project — it and "My AI Course" here **coexist, switch anytime, and don't interfere**. Don't overthink where things go.

---

## Step 0: Set up your learning workspace

Open Cowork and create a new **empty folder** as your course learning project (call it `My AI Course`, say). Empty is correct — what goes in it grows out of you and the AI working together.

Suggested folder structure (build it as you go; it doesn't have to be complete on day one):

```
My AI Course/
├── course-notes/
│   ├── ppt/                        # put the course slides here
│   ├── follow-along-prompts-en.md  # the demo prompt list from the zip,
│   │                               # each step tagged "what this step does" (very useful!)
│   ├── my-notes.md                 # jot as you go, whatever comes to mind
│   ├── terms-i-dont-get.md         # jargon and concepts you didn't follow
│   └── course-summary.md           # have the AI generate this one
├── class-project/                  # do the class demo yourself
└── homework-project/
    └── assignment.md               # homework-guide-en.md from the zip, just renamed
```

💡 **Scared of `.md`? `.txt` works just as well.** If those `.md` files feel like a hassle, make them all `.txt` (built-in Notepad can write those). The AI reads them fine and summarizes them just the same. `.md` only makes the formatting a bit nicer — don't let file formats stop you from starting.

💬 **Real example (copy it directly)** — don't create all those folders by hand. Paste the whole structure block above to the AI:

> Create the folder structure below for me; I'll add the files gradually
>
> (paste the whole "My AI Course/…" structure block here)

**What this step does**: gets the AI to build your entire course folder skeleton in one shot, so all you do afterwards is drop files in.

---

## Step 1: Take notes + have the AI summarize

**You write first, then let the AI fill in.** The order matters — the AI is there to deepen your thinking, not to remember class for you.

1. In `my-notes.md`, recall as much of the class as you can and write down your takeaways. **It doesn't have to be polished** — fragments and half-sentences are fine.
2. In `terms-i-dont-get.md`, write down the jargon and concepts you didn't quite follow.
3. Put the slides in the `ppt/` folder, then put **`follow-along-prompts-en.md`** from the zip into `course-notes/` too — it's the **prompt list** from the class demo, with a "what this step does" tag on every step, so the AI can reconstruct exactly what each step was doing.
4. Then have the AI summarize the class using your notes, the slides, and `follow-along-prompts-en.md` together. **Ask several times**, going deeper each round, and finish by asking it to **output a `course-summary.md` file** you can revisit later.

> 📎 **Why `follow-along-prompts-en.md` matters**: the slides are "what was said"; `follow-along-prompts-en.md` is "which prompts were actually sent." When a step didn't land or you can't recall a demo detail, having the AI consult `follow-along-prompts-en.md` gives you a far more accurate answer than explaining from thin air.

**Example prompts** (copy them, then make them yours):

> - "Using my notes (`my-notes.md`), the slides (files in `ppt/`), and `follow-along-prompts-en.md`, summarize this class for me and save it to `course-summary.md`."
> - "I didn't follow the '___' step in the demo. Using `follow-along-prompts-en.md`, explain clearly what that step was doing and why it was done that way."
> - "I don't really understand how to set up Gmail in Cowork. Give me more detailed step-by-step instructions and add them to the summary file."
> - "I still have no mental model for 'how to write a good prompt.' Walk me through it systematically and add it to the summary."

💡 **Technique**: feed the AI your "terms I don't get" one by one, have it explain each in plain language with examples, then have it write the explanations back into `terms-i-dont-get.md`. By the end of one class you'll have your own glossary.

💬 **Real example (what a student actually typed — copy and adapt)** — the point is you just **talk**, and leave opening files / writing / formatting entirely to the AI:

> - Log a takeaway (the AI writes it into `my-notes.md` automatically):
>   **"Add this to my notes: if I can direct Cowork to do it, let Cowork do it — I'm the director."**
> - Log a term you don't get (the AI explains, then saves it to `terms-i-dont-get.md`):
>   **"I don't really get what dispatch means."**
> - Ask for steps on something you can't do (then log it into your notes):
>   **"I don't understand how to configure Gmail in Cowork. Give me more detailed step-by-step instructions."**
> - Add new thoughts anytime:
>   **"Add the following to my notes as well: you can write prompts however you like — if it's not good, discuss it with the AI and let it improve; if it's wrong, you can have it redo."**
> - Have the AI format for you:
>   **"Can you number each takeaway? Make it a bit friendlier to read."**

**The one-line trick**: you're the director — **speak the content, and leave creating files, writing, and formatting to the AI.**

---

## Step 2: Do the class project with your own hands

**Only doing it yourself gives you a real feel for it.** Watch the recording, work from the course materials, and rebuild the whole thing from scratch inside `class-project/`.

- **Experiment freely** — the AI is forgiving, and getting it wrong doesn't matter.
- When the AI's result isn't quite right, **tell it exactly what's wrong and have it fix it**. That "I say, it revises" loop is the single most important skill in this course.
- As you go, keep logging takeaways, potholes you fell into, and things that suddenly clicked into `course-notes/my-notes.md`, and have the AI keep summarizing.

---

## Step 3: Homework = solving a real pain point of your own

Homework isn't a box to tick — it's **using this class's capability to solve one pain point in your actual work**. The project can be big or small.

**Start from the pain point** — it might be:
- Something **repetitive and monotonous** (exporting the same report daily, formatting the same kind of document); or
- A pile of **small scattered chores** (no fixed process, but genuinely annoying).

**Then two cases:**

| Your situation | What to do |
|---------------|-----------|
| The pain point **already has a fixed process** | Try moving that process into Cowork as an agent / workflow |
| The pain point **isn't shaped yet** | Give the AI "the assignment + a description of your pain point" together, have it propose approaches, and **save the result to a file** |

**The key is iteration** — don't stop once you get the AI's first suggestion. Refine it together, **exactly the way I kept improving prompts while building the agents**: you raise a point, it revises, you raise another… a few rounds in, the plan takes shape. Keep writing your takeaways throughout.

**Example prompt**:

> "Here's my assignment (`assignment.md`). My day-to-day pain point is ___. Analyze whether this pain point is a good fit for AI/Cowork, give me 2-3 approaches, save them as `approaches.md`, and tell me which one is the simplest to get running first."

💬 **Real example (filled in — swap in your own pain point)**:

> "Here's my assignment (`assignment.md`, which is `homework-guide-en.md`). My day-to-day pain point is **spending way too much time writing weekly reports**. Analyze whether this pain point is a good fit for AI/Cowork, give me 2-3 approaches, save them as `approaches.md`, and tell me which one is the simplest to get running first."

---

## Step 4: Have the AI write me an email = submit your homework

Finally, pull together everything you've learned along the way plus your homework, and have the AI write me an email.

> 📌 **Important**: this email **is your homework submission** — every item the assignment asks for must appear in it. **Not one can be missing.** Having the AI write it doesn't mean the AI gets to skip things. So spell out every requirement in your prompt and make it fill each one in.

**What the assignment requires (the email body must cover all of it):**
1. **Workflow design** — which Agents you designed, what each is responsible for, and how data passes from one to the next.
2. **Each Agent's prompt** — all three elements present (role / task / output format), plus the input format and the `OUTPUTS/` path.
3. **Actual run output** — the real results each Agent produced (not placeholders, not "[omitted]").
4. **Reflection** — 200+ words, with at least **3 concrete personal observations** ("this tool is useful" doesn't count; write what you actually discovered).

**Example prompt** (copy it, swap the paths for your own):

> "Using my homework project (the `homework-project/` folder) and my course notes (the `course-notes/` folder), write me an email to the instructor submitting my homework. **Every item the assignment requires must appear in full in the email body — none may be omitted.** Organize it in these four blocks:
> 1. Workflow design: list each Agent I designed, what each does, and how data passes between them;
> 2. Each Agent's prompt: paste them verbatim, confirm all three elements (role/task/output format) are present, and include the input format and `OUTPUTS/` path;
> 3. Actual run output: paste in the real results each Agent produced — no placeholders;
> 4. Reflection: 200+ words with at least 3 concrete observations of my own.
> Then add a short paragraph at the end with questions I'd still like to ask. Sincere and concise in tone. Before finishing, produce a checklist and verify none of the four items are missing."

What I want to see isn't perfection — it's that **you actually did the work and actually thought about it**. Confusion and sticking points are especially welcome; those are exactly what I can help with in the next class.

---

## In one line

> **Write notes → have the AI summarize → do it yourself → solve a real pain point → send it back to me.**
> Do every step by hand, and leave a record at every step. The capability in this course comes from *doing*, not from *listening*.
