# Follow Along · Session 1 Demo Prompts

> In class I'll type these prompts one at a time. **Copy and paste them in order** and you'll build the job-search pipeline alongside me.
> Don't try to get it perfect on the first pass — you'll watch the process of **write a bare-bones version → let AI improve it → iterate**.
>
> **Before you start:**
> 1. Download the course materials zip and unzip it. Inside you'll find a `starter-project/` folder (with `alex-chen-resume.md` and `5c-methodology.md`). In Cowork click **Create Project** and point the project at that folder.
>    (This demo lives in its **own Project**. The "My AI Course" project you use for notes is a separate one — both can exist at once, switch anytime, they don't interfere. Don't overthink where things go.)
> 2. Email both JDs (`virtual-jd.md`, `virtual-jd-2.md`) **to yourself**:
>    Open your own Gmail → compose → **put your own address in To** → copy the subject line written at the top of each file (e.g. `JD: Staff Platform Engineer @ NovaDeploy`) → paste the entire JD file contents into the body → send. Do this for both.
>    (Step 0 uses the Gmail Connector to read the email whose *subject contains NovaDeploy* — so it has to be in your inbox first.)
> 3. Connect Gmail under Project Settings → Connectors
> 4. **Know where the approval mode lives**: there's a mode selector in the composer (Manual / Auto / Skip).
>    **Leave it on the default Manual** for Step 0 — you'll see Claude stop and ask before every email read and file write. That's its permission system; it won't touch your files behind your back.
>    **Once you've seen it work, switch to Auto**: the dozen-plus file operations that follow will run straight through without interrupting you, and genuinely unsafe actions still get blocked automatically.
>    (Don't use Skip — that turns off the safety checks too.)

---

> ## ⚡ Saving quota on Pro ($20)
>
> This pipeline is a "heavy" workload (Gmail connector, lots of file I/O, long outputs at every step). One 5-hour Pro usage window may not cover the whole thing. Do this and you'll be fine:
>
> 1. **Stay on the default Sonnet model, don't switch to Opus** — Sonnet 5 is more than enough here. Opus quota on Pro is tiny; switching will strand you mid-run.
> 2. **Split it across two sessions**: get Part 1 (Agents 1–4) working first; save Part 2 ("check new JD") and the weekly review for the next 5-hour window.
> 3. **Want to save more**: halve the length requirements in the prompts (e.g. `1500-2000 words` → `800-1000 words`). Output tokens are the biggest cost.
> 4. **Avoid peak hours**: 5–11 AM Pacific is tighter. Pick another slot.
> 5. **Don't panic if you hit the cap**: everything is saved in the Project (`pipeline-prompts.md` + `OUTPUTS/`). Pick up where you left off after the quota resets — that's exactly the payoff of "files are the source of truth."

---

## Step 0 · Read the JD from Gmail, save it as a file

> 👉 **What this step does**: have AI pull the JD text out of Gmail and save it as a file — all four Agents downstream read that same file.

Start a new Cowork conversation and enter:

```
Check my Gmail, find the email whose subject contains "NovaDeploy",
and extract the original JD text.
Based on the company and role, create a subfolder under the OUTPUTS
directory of my current project folder, save it as
OUTPUTS/{subfolder}/jd-original.md, and tell me the folder name.
```

**Save the entry prompt (the start of the Pipeline):**

```
Take the prompt I just used to read the JD from Gmail, clean it up,
and save it to pipeline-prompts.md (create it directly, not inside OUTPUTS).

Format:
## Entry — Gmail trigger
Input: Gmail (emails whose subject contains "JD:")
Output: OUTPUTS/{company-folder}/jd-original.md

[trigger prompt]

---
```

---

## Agent 1 · JD Analysis

> 👉 **What this step does**: evaluate whether this opportunity is worth pursuing, by your standards. The technique you're learning is **write a bare-bones version → have AI fill in the structure → iterate until it's specific**.

**① Bare-bones version (just make it run)**

```
You are a job-search strategy consultant.
Evaluate this opportunity using C1 from 5c-methodology.md:
- JD: the jd-original.md I just saved (in this company's folder)
- Resume: alex-chen-resume.md
Give me a verdict on whether it's worth applying.
Save it to jd-analysis.md in the same company folder.
Keep it to 1000-1500 words.
```

**② Have AI improve the prompt**

```
I want to make the JD-analysis prompt above more professional and more reusable.
As a job-search strategy consultant, what other sections should a good JD analysis
include? It must include "capability gaps + a concrete remediation plan"
(a JD and a resume are almost never a perfect match).
Please improve the prompt, spell out the output structure explicitly,
then re-run the analysis with the improved version
(still updating the same jd-analysis.md).
Keep it to 1000-1500 words.
```

**③ Iterate: force the remediation plan to get specific**

```
The capability-gap section is too vague.
For the Backstage experience gap specifically, give me a concrete 2-week
remediation plan — what to read, what to build, and how to answer honestly
in an interview without losing points.
Please update jd-analysis.md.
Keep it to 1500-2000 words.
```

**④ Save the improved prompt into pipeline-prompts.md**

```
Please clean up the improved Agent 1 prompt and save it to pipeline-prompts.md
(create it directly, not inside OUTPUTS).

Cleanup requirements:
- Rewrite relative phrases like "this company's folder" / "the same folder"
  as the placeholder {company-folder} (same below)
- Save only the improved version — it already covers capability gaps and the
  remediation plan, so there's no need for a separate follow-up section

Format:
## Agent 1 — JD Analysis
Input: OUTPUTS/{company-folder}/jd-original.md + alex-chen-resume.md
Output: OUTPUTS/{company-folder}/jd-analysis.md

[improved prompt]

---
```

---

## Agent 2 · Company Research

> 👉 **What this step does**: research the target company to build ammunition for the outreach step. Same pattern — **bare-bones → have AI improve it**.

**① Bare-bones version**

```
Research the target company using C3 from 5c-methodology.md — this step is
research only, do NOT write the outreach yet (that's the next step).
The original JD is in this company's folder.
Save it to company-research.md in the same folder.
Keep it to 1500-2000 words.
```

**② Have AI improve it**

```
Help me improve this company-research prompt: what sections should company
research contain to actually be useful for a job search?
Spell out the output structure explicitly, then re-run the research with the
improved version (still research only, no outreach, still updating the same
company-research.md).
```

**③ Append to pipeline-prompts.md**

```
Clean up the Agent 2 (company research) prompt and append it to pipeline-prompts.md:
- Rewrite the relative folder references as {company-folder}
- Add input/output annotations

Format:
## Agent 2 — Company Research
Input: OUTPUTS/{company-folder}/jd-original.md
Output: OUTPUTS/{company-folder}/company-research.md

[cleaned-up prompt]

---
```

---

## Agent 3 · LinkedIn Outreach (two rounds of iteration)

> 👉 **What this step does**: pull everything together into one tailored outreach message. The real lesson is **two-round iteration + having AI critique its own output** — that transfers to any scenario.

**① First draft**

```
Read the following files and, using the C3 (Connection) outreach standard
from 5c-methodology.md, draft a LinkedIn connection-request note aimed at an
engineer or EM at the target company:
- Resume: alex-chen-resume.md
- JD analysis: jd-analysis.md in this company's folder
- Company research: company-research.md in this company's folder

Format: 150-200 words, in English.
Save it to linkedin-outreach.md in the same folder.
```

**② Make it sound human, keep both versions**

```
This note still reads like a template — like Claude Cowork wrote it.
Help me make it sound more like a real person talking: use first person,
make the KubeCon common ground far more specific, and make the closing
question feel like I genuinely want their opinion, not like small talk.

Write BOTH versions into linkedin-outreach.md with version headings
(## V1 First Draft / ## V2 Human Voice) so they're easy to compare.
```

**③ Quality check**

```
Please quality-check the V2 version in linkedin-outreach.md against the
following criteria, scoring each 1-5:
1. Human feel: does it read like a person or an AI template?
2. Personalization: is there a specific hook, rather than a generic
   "I looked at your company"?
3. Call to action: will the closing question actually get a reply?
4. Length: is it within 150-200 words?

If any item scores below 4, write an improved V3 directly and append it to
linkedin-outreach.md under a ## V3 Revised heading.
If everything scores 4-5, say the quality bar is met and don't rewrite.
```

**④ Append to pipeline-prompts.md (including the quality-check step)**

```
Clean up the Agent 3 (Outreach) prompt and append it to pipeline-prompts.md:
- Rewrite the relative folder references as {company-folder}
- Save the final version that passed the quality check (include the
  quality-check step)

Format:
## Agent 3 — LinkedIn Outreach
Input: alex-chen-resume.md + OUTPUTS/{company-folder}/jd-analysis.md
       + OUTPUTS/{company-folder}/company-research.md
Output: OUTPUTS/{company-folder}/linkedin-outreach.md

[final prompt, including the quality-check step]

---
```

---

## Agent 4 · Pipeline Tracking

> 👉 **What this step does**: log this application in a tracker and de-duplicate. Results land in files, so they accumulate and stay reusable.

**① The prompt**

```
Read jd-analysis.md in this company's folder, follow the pipeline-management
principles from C4 (Conversion) in the project file 5c-methodology.md, and
append one tracking record to OUTPUTS/pipeline-tracker.md
(append — do not overwrite existing content).

Watch for duplicates: use pipeline-status.md to record the processing state of
each JD, and skip any that have already been handled — don't log them twice.
```

**② Append to pipeline-prompts.md**

```
Clean up the Agent 4 (Pipeline tracking) prompt and append it to pipeline-prompts.md:
- Rewrite the relative folder references as {company-folder}
- Add input/output annotations

Format:
## Agent 4 — Pipeline Tracking
Input: OUTPUTS/{company-folder}/jd-analysis.md + pipeline-status.md
Output: OUTPUTS/pipeline-tracker.md (append one row)
        + pipeline-status.md (update state)

[cleaned-up prompt]

---
```

---

## Transition · Have Claude write your Project Instructions

> 👉 **What this step does**: wire those 4 prompts into a single automated pipeline — from now on, sending "check new JD" runs them all in order.

```
Write me a set of Project Instructions to put in this Project's Settings:

Trigger phrase "check new JD": read pipeline-prompts.md and execute each
Agent step in order.

Keep it short and usable, under 150 words.
```

Paste the result into the **Project's Instructions** (depending on your version this may show as Instructions or Custom Instructions — same place).

> Note: Cowork has two layers of instructions — **Global Instructions** (Settings → Cowork, applies to every session) and **Project Instructions** (only inside this Project). Use the latter here. Don't put it in Global, or this trigger phrase will fire in your other projects too.

---

## Part 2 · One-line reuse (new conversation, HyperScale)

> 👉 **What this step does**: prove the reuse payoff — swap in a brand-new JD, send one sentence, and all 4 Agents run automatically.

Start a new conversation and send just this:

```
check new JD
```

All 4 Agents run in sequence → a new company folder appears containing jd-original / jd-analysis / company-research / linkedin-outreach, and pipeline-tracker gets a new row automatically.

---

## Finale · Package the pipeline into a Skill

> 👉 **What this step does**: upgrade `pipeline-prompts.md` into a Skill — from "works inside this Project" to "works in any Project," something you carry with you.
>
> This step only works *because* you saved each Agent's prompt to a file as you went. **If those prompts had only lived in the chat history, there'd be nothing here to package.**

**① Say it all in one message** (send `/skill-creator` together with the details — no need to split it up)

```
/skill-creator
Turn the whole job-search pipeline in pipeline-prompts.md into a Skill,
named job-pipeline,
trigger: whenever I say I want to process a new JD or job opportunity.
```

**② Watch what it does**

Because you gave it the name, the trigger condition, and the source file **all at once**, it won't ask follow-up questions — it goes straight to work:

```
Now I have everything I need. Let me write the skill.
  → Saved skill: job-pipeline          ← saved to your account automatically
  → then writes a mock JD and test-runs it to verify the trigger and flow
```

Notice that last step — **it verifies its own work**: it invents a mock JD, runs it through, and confirms the Skill triggers correctly and the flow holds together.

> If you send only `/skill-creator` with no details, it will turn around and ask you what to build and when it should trigger.
> Saying it all at once skips that round-trip — which is the same thing you've been practicing all along.

**③ Verify**

Start a new conversation, say "take a look at this new JD opportunity," and see whether job-pipeline fires on its own.

> **Project Instructions vs Skill**:
> Project Instructions only apply inside this Project. **A Skill lives in your account** — it works in any project, and you can share it with other people.
> So the order matters: get it working in one Project → once it's stable → upgrade it to a Skill.

> 💡 **The other path: teach it by recording**
> Some workflows you can't really describe — you can only show them (clicking around some legacy system, say).
> For those, use **Record a Skill**: `+` menu → Record a skill, then narrate out loud while you work, and Claude learns from the recording.
> It's a desktop feature (the official docs say Mac), available on Pro / Max / Team, rolling out in phases.
> Our pipeline here is entirely prompt-driven, so skill-creator is the more direct route.

---

## Weekly Review (optional)

> 👉 **What this step does**: have AI read the tracker and set next week's priorities + update your schedule. Once you're happy with it, save it to a file, freeze it behind a trigger phrase, and schedule it to run on its own.

**① Send the prompt, run the weekly review + schedule update**

```
Read OUTPUTS/pipeline-tracker.md and do a weekly review of my job-search
pipeline — which ones need follow-up, which to put on hold, which two or
three to push next week.
Save the review report to OUTPUTS/weekly-review-{today's date}.md;
then write the follow-up actions (send outreach, schedule interviews,
submit materials, etc.) into OUTPUTS/weekly-schedule.md,
listed by date with the highest priority first.
```

**② Save the prompt to a file**

```
Clean up the "weekly review" prompt I just used and save it to
weekly-report-prompt.md (in the project root, not in OUTPUTS).
```

**③ Update your Project Instructions with a trigger phrase**

Send to Claude (or append directly to the Project's Instructions):
```
Append to the existing Project Instructions:

Trigger phrase "weekly review": read weekly-report-prompt.md and follow
the steps in it.
```

Update the **Project's Instructions** with the result.

**④ Schedule it weekly**

**Left sidebar → Scheduled → New task**, then either route:
- **Create with Claude**: it asks you a few questions and configures the task for you
- **Set up manually**: fill in the task name, prompt (enter "weekly review"), approval mode, frequency (choose Weekly), and time (e.g. Friday 17:00)

Once saved, the status flips to Active.

> 💡 **Scheduled tasks run in the cloud** — your computer can be asleep, the desktop app can be closed, and it still runs on schedule. That's what "the system runs itself" actually means.
> (Scheduled tasks require a paid plan: Pro / Max / Team / Enterprise.)

> The order matters: describe what you want and run it once → once you're happy, save it to a file → freeze it behind a trigger phrase → then schedule it. That's a system that runs itself.
