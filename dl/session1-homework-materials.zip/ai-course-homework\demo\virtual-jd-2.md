# 演示用职位描述（JD #2）— 第二段「检查新JD」复用演示专用

> **怎么用这个文件：** 把下面的 JD 正文，以邮件**发给你自己**——
> 收件人填你自己的邮箱 → 主题写 `JD: AI Infrastructure Manager @ HyperScale` → 正文粘下面全文 → 发送。
> 第二段在新对话发「检查新JD」，4 个 Agent 会自动依次跑完。
>
> （这条 JD 匹配度约 6-7 分＝「观望」，故意的——体现系统帮你快速筛选：不是每封 JD 都值得全力投入。）

---

**职位：** AI Infrastructure Manager
**公司：** HyperScale（上市云计算公司，约 8,000 人）
**地点：** Hybrid（Seattle, WA，每周 3 天进办公室）
**薪资范围：** $180k–$220k + RSU

---

## About HyperScale

HyperScale provides enterprise cloud infrastructure for Fortune 500 companies. Our AI division manages one of the largest GPU fleets in North America, running LLM training and inference workloads for 200+ enterprise clients.

## The Role

We're hiring an AI Infrastructure Manager to lead a team of 12 engineers responsible for GPU cluster operations, ML platform tooling, and infrastructure reliability for our AI cloud product.

## What You'll Do

- Manage day-to-day operations of 10,000+ GPU cluster (H100/A100) across 3 data centers
- Build and maintain ML platform services: job scheduling, model registry, experiment tracking
- Drive SLA commitments for GPU availability (target: 99.9%) across enterprise clients
- Lead a team of 12 infrastructure and ML platform engineers
- Collaborate with sales and customer success on enterprise client onboarding
- Own budget planning for $50M+ annual infrastructure spend

## Required

- 10+ years of infrastructure engineering experience
- 3+ years in a people management role (team of 8+)
- Hands-on experience with GPU infrastructure (CUDA, NCCL, distributed training)
- Experience operating large-scale Kubernetes clusters in production
- Strong communication skills for executive and client-facing presentations
- Experience with budgeting and vendor management

## Nice to Have

- Experience at a public cloud company or hyperscaler
- Familiarity with SLURM, Ray, or similar HPC/ML job schedulers
- MBA or equivalent business education
- Background in enterprise sales support or solutions engineering

## Interview Process

1. Recruiter screen (30 min)
2. Hiring manager interview (45 min)
3. Panel: Technical + People Management + Business Acumen (3 hours)
4. Executive interview + offer
