# 5C Job Search Methodology

**Author:** Nan Li (MidCareer Reboot)  
**Purpose:** Reference framework for AI-assisted job search pipeline

---

## C1 — Clarity: Know exactly what you want before applying

Evaluate every opportunity against three filters:

- **Passion fit**: Does this role energize rather than drain? Would you do this work even if no one was watching?
- **Unique skills fit**: Does this role leverage what only *you* can do — your specific combination of experience, perspective, and expertise?
- **Market demand**: Is this role/industry gaining momentum, not shrinking?

**In practice:** Score each JD on fit (1–10). Conclude with one of three verdicts:
- **全力投入** — strong fit across all three dimensions
- **观望** — partial fit, proceed cautiously
- **跳过** — misaligned; don't spend energy here

*Go slow at the beginning to go fast at the end. Without Clarity, the rest of the framework doesn't work.*

---

## C2 — Confidence: Show up knowing your worth

Before each interview or outreach, identify and close your gaps:

- Where is your confidence genuine vs. performed?
- Where are you borrowing language instead of owning understanding?
- What specific, recent evidence proves your competence (not just your title)?

**In practice:** For each role, prepare 2–3 concrete examples of outcomes you drove independently — not what your team did, what *you* contributed.

---

## C3 — Connection: Build relationships before you need them

Most jobs are filled before they are posted. Connection strategy:

- Research the company and find where their people are active (conferences, communities, publications)
- Lead with giving: share a relevant insight, ask a genuine question, reference something specific about their work
- Never send a generic outreach. Always find one specific, authentic hook from the person's background or company's recent activity
- Goal: be memorable for your current thinking, not your old title

**In practice:** Every outreach message should have a specific hook, a genuine reason for reaching out, and an open-ended question that invites a real reply — not a request for a referral.

---

## C4 — Conversion: Run your search like a sales pipeline

Turn conversations into interviews and interviews into offers — with a system, not luck:

- Track every opportunity across stages: initial contact → outreach sent → response → interview → final round → offer
- Never let a warm lead go cold by default — always have a defined next action and a follow-up date
- Maintain 10–15 active conversations simultaneously; a single cancellation is a setback, not a crisis
- 6+ opportunities can disappear due to reorgs, budget freezes, or leadership changes — that's the market, not your fault

**In practice:** Every pipeline entry needs: company, role, source, status, next action, deadline, match score.

*Treat your job search like a sales pipeline. Never bet everything on one deal.*

---

## C5 — Commitment: Choose alignment, not just compensation

After the offer:

- Evaluate each offer against your C1 Clarity criteria — not just the salary
- Know *why* you're taking this role and what it's preparing you for
- Use the first 90 days to onboard fast and perform immediately
- Keep your longer-term roadmap alive even after accepting

**In practice:** Before accepting, answer: "Does this role move me toward where I want to be in 3–5 years, or just away from where I am now?"
