# 演示用简历（Resume）

> 用途：Session 1 Cowork 演示的背景素材。配合 virtual-jd.md 使用。
> Agent 1 用于精准匹配分析，Agent 3 用于生成个性化 Outreach。

---

**Alex Chen**
Platform Engineering Leader · Remote (US)
alex.chen@example.com | linkedin.com/in/alexchen-platform | github.com/alexchen-infra

---

## Summary

Staff Platform Engineer with 12 years of experience building and scaling infrastructure platforms for high-growth technology companies. Deep expertise in Kubernetes at scale, internal developer platforms, and AI/ML infrastructure. Proven track record of reducing time-to-production and enabling engineering teams of 200+ to ship faster and more reliably.

---

## Experience

### Staff Platform Engineer — eBay
*2020 – Present (5 years)*

- Led the design and delivery of eBay's Internal Developer Platform (IDP), consolidating 6 fragmented toolchains into a single self-service portal adopted by 800+ engineers across 60+ product teams
- Owned Kubernetes platform at scale: 3,000+ node multi-cluster deployment across GCP and on-prem, including cluster upgrades, multi-tenancy isolation, and 40% cost reduction via workload right-sizing
- Built golden-path templates and service catalog that cut new service onboarding from 3 weeks to 2 days
- Established SLOs for platform services; led weekly incident reviews and drove MTTR from 4 hours to 45 minutes
- Managed and mentored a team of 8 platform engineers; defined career ladders and promoted 3 engineers to senior/staff level
- Partnered with AI/ML team to provision GPU clusters for model training (NVIDIA A100, multi-node distributed training); designed job scheduling system handling 50+ concurrent training jobs

### Senior Infrastructure Engineer — Wish (ContextLogic)
*2017 – 2020 (3 years)*

- Migrated 200+ microservices from bare-metal to Kubernetes on GCP; reduced infrastructure costs by $2M/year
- Built CI/CD pipelines with Tekton and ArgoCD; deployment frequency increased 5× (weekly → daily)
- Designed multi-region disaster recovery; achieved 99.95% platform availability
- Wrote platform tooling in Go (internal CLI, drift detection, capacity planning automation)

### Infrastructure Engineer — Rakuten
*2014 – 2017 (3 years)*

- Maintained AWS infrastructure for e-commerce platform (EC2, RDS, ElastiCache, CloudFront)
- Automated provisioning with Terraform and Ansible; eliminated 80% of manual toil
- Built alerting and observability stack: Prometheus, Grafana, PagerDuty

### Systems Engineer — Neusoft
*2012 – 2014 (2 years)*

- Linux system administration, network configuration, on-call support for enterprise clients

---

## Skills

**Orchestration:** Kubernetes (CKA certified), Helm, Kustomize, Operators
**Cloud:** GCP (Professional Cloud Architect), AWS (Solutions Architect Associate)
**Languages:** Go (primary), Python, Bash; familiar with TypeScript
**IDP / DevX:** Internal developer portals, service catalog, golden paths, self-service infra provisioning
**AI/ML Infra:** GPU cluster provisioning (A100/H100), distributed training orchestration, Ray, NCCL
**Observability:** Prometheus, Grafana, OpenTelemetry, Jaeger
**CI/CD:** Tekton, ArgoCD, GitHub Actions
**Security:** RBAC, OPA/Gatekeeper, Vault, SPIFFE/SPIRE

---

## Education

**B.S. Computer Science** — Tongji University, Shanghai (2012)

---

## Notable

- Speaker, KubeCon NA 2023: *"Scaling Multi-Tenant Kubernetes at Scale: Lessons from 3,000 Nodes"*
- Open source contributor: kubernetes-sigs/cluster-api (minor patches), internal IDP tooling open-sourced with 800+ GitHub stars
- Technical blog: platform engineering, AI infrastructure, career development
