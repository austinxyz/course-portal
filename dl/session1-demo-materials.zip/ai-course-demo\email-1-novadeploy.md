# 演示邮件 1 — 第二步 Connector 触发用

**To:** austin.aicourse@gmail.com
**Subject:** JD: Staff Platform Engineer @ NovaDeploy

---

Hi,

Sharing a JD that might be a good fit for your background.

---

**Position:** Staff Platform Engineer
**Company:** NovaDeploy (Series B, ~300 people, cloud infrastructure)
**Location:** Remote (US)
**Compensation:** $190k–$240k + equity

---

NovaDeploy helps engineering teams ship faster by providing a unified developer platform — internal developer portal, CI/CD orchestration, and infrastructure self-service. Our platform is used by 500+ engineers across 40+ product teams. We're Series B, profitable, and growing 80% YoY.

We're looking for a Staff Platform Engineer to lead the next phase of our Internal Developer Platform (IDP). You'll own the technical roadmap for developer experience tooling, work closely with platform and product engineering teams, and mentor a team of 6 engineers.

**What You'll Do**

- Design and evolve our IDP: self-service infrastructure provisioning, service catalog, golden paths for new services
- Own the Kubernetes platform (2,000+ nodes across GCP and AWS), including cluster upgrades, multi-tenancy, and cost optimization
- Drive adoption of platform capabilities — work with product teams to reduce time-to-production from days to hours
- Establish SLOs for platform services; lead incident response and post-mortems
- Mentor 6 platform engineers; participate in hiring and technical interviews
- Collaborate with AI/ML team on GPU cluster provisioning and training job orchestration

**Required**

- 8+ years of software/infrastructure engineering experience
- 4+ years with Kubernetes in production (multi-cluster, multi-cloud preferred)
- Strong proficiency in Go or Python for platform tooling
- Experience building Internal Developer Platforms or similar developer experience products
- Proven ability to drive adoption of platform capabilities across engineering orgs
- Track record of leading technical initiatives and mentoring engineers

**Nice to Have**

- Experience with Backstage or similar IDP frameworks
- Familiarity with GPU/ML infrastructure (CUDA, NCCL, Slurm, Ray)
- Experience in high-growth startups (Series A–C)
- Published writing or talks on platform engineering

**Interview Process**

1. Recruiter screen (30 min)
2. Technical phone screen (45 min)
3. Virtual onsite: System Design + Platform Deep Dive + Behavioral (4.5 hours)
4. Reference checks + offer
