# 演示邮件 2 — 第七步「检查新JD」触发用

**To:** austin.aicourse@gmail.com
**Subject:** JD: AI Infrastructure Manager @ HyperScale

---

Hi,

Another JD for your consideration — slightly different profile, thought it was worth a look.

---

**Position:** AI Infrastructure Manager
**Company:** HyperScale (public cloud company, ~8,000 people)
**Location:** Hybrid (Seattle, WA — 3 days/week in office)
**Compensation:** $180k–$220k + RSU

---

HyperScale provides enterprise cloud infrastructure for Fortune 500 companies. Our AI division manages one of the largest GPU fleets in North America, running LLM training and inference workloads for 200+ enterprise clients.

We're hiring an AI Infrastructure Manager to lead a team of 12 engineers responsible for GPU cluster operations, ML platform tooling, and infrastructure reliability for our AI cloud product.

**What You'll Do**

- Manage day-to-day operations of 10,000+ GPU cluster (H100/A100) across 3 data centers
- Build and maintain ML platform services: job scheduling, model registry, experiment tracking
- Drive SLA commitments for GPU availability (target: 99.9%) across enterprise clients
- Lead a team of 12 infrastructure and ML platform engineers
- Collaborate with sales and customer success on enterprise client onboarding
- Own budget planning for $50M+ annual infrastructure spend

**Required**

- 10+ years of infrastructure engineering experience
- 3+ years in a people management role (team of 8+)
- Hands-on experience with GPU infrastructure (CUDA, NCCL, distributed training)
- Experience operating large-scale Kubernetes clusters in production
- Strong communication skills for executive and client-facing presentations
- Experience with budgeting and vendor management

**Nice to Have**

- Experience at a public cloud company or hyperscaler
- Familiarity with SLURM, Ray, or similar HPC/ML job schedulers
- MBA or equivalent business education
- Background in enterprise sales support or solutions engineering

**Interview Process**

1. Recruiter screen (30 min)
2. Hiring manager interview (45 min)
3. Panel: Technical + People Management + Business Acumen (3 hours)
4. Executive interview + offer
