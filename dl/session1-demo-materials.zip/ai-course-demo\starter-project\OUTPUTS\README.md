# OUTPUTS（产出目录）

初始为空——流水线运行时，AI 会自动往这里写文件，你不用手动建。

每处理一条 JD，AI 据公司 + 职位自起一个子目录（kebab-case），写入：

```
OUTPUTS/
  {公司目录}/                  ← 如 novadeploy-staff-platform/
    jd-original.md             ← Gmail 提取的 JD 原文
    jd-analysis.md             ← Agent 1：匹配度 + 值不值得投 + 能力缺口
    company-research.md        ← Agent 2：公司调研
    linkedin-outreach.md       ← Agent 3：LinkedIn 连接附言
  pipeline-tracker.md          ← Agent 4：全局求职追踪表（每条 JD 追加一行）
  pipeline-status.md           ← 去重状态（Agent 4 首次运行自动创建）
```

> 这个目录是给 AI 写产出用的；你的初始文件（简历、5C 方法论）放在上一层。
