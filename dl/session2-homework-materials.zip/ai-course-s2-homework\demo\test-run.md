# Session 2 演示复现脚本（学员版）

> 目标：在自己的电脑上把今天的演示跑一遍，验证环境正常、流程走通。
> 预计时长：30-40 分钟。两段：**建武器**（建知识库）→ **用武器赚钱**（客户服务出 PPT）。

---

## 前置条件

- [ ] Claude Code 已安装并登录（`claude` 命令可用）
- [ ] Obsidian 已安装（用来打开知识库、看关系图）
- [ ] superpowers + ppt-master 两个社区 Skills（Part 2 第 5 步装，命令见下）

---

# Part 1 · 建武器（建北美华人理财知识库，约 20 分钟）

## Step 1：初始化项目目录（5 分钟）

1. 创建一个新的空目录（名字随意，如 `wealth-demo`）
2. 在该目录下打开 Claude Code

**提示词：**
```
请帮我初始化一个北美华人个人理财知识库项目。
参考 LLM Wiki 方法论，创建三层目录结构：
- raw_material/：原始素材区
- wiki/：结构化知识库
- output/：客户档案区（隐私区，不进 Git）

同时创建 CLAUDE.md，说明项目结构和隐私规则
（output/ 下的客户数据不进 Git，加入 .gitignore）。
```

**预期输出：**
```
wealth-demo/
├── CLAUDE.md
├── .gitignore        （含 output/）
├── raw_material/
├── wiki/
└── output/
```

---

## Step 2：建 raw_material/ 骨架（5 分钟）

**提示词：**
```
请为这个北美华人个人理财知识库规划 raw_material/ 的分类结构。
在 raw_material/ 下创建子目录，每个子目录创建 README.md，
列出该分类下建议收录的知识条目清单。
```

**预期输出：** `retirement/`、`tax/`、`education/`、`insurance/` 等子目录，每个含 README。

---

## Step 3：写第一条 wiki + 顺手建 `/wiki-extract` Skill（5 分钟）

**3a. 先手动写第一条 wiki：**
```
请读取 raw_material/ 下某个 README.md，从清单里挑一个条目（如 401K rollover），
搜索相关权威信息：
1. 把原始内容（含来源链接）保存到 raw_material/ 对应子目录
2. 提炼成一篇 wiki 条目，保存到 wiki/ 对应位置

wiki 结构：概述 → 核心要点 → 常见误区 → 相关条目
```
**预期：** 如 `wiki/retirement/401k-rollover.md`，结构清晰、有来源引用。

**3b. 把这套提取流程封装成 Skill：**
```
请把刚才"搜索原始资料 → 存 raw_material/ → 提炼成 wiki 条目存 wiki/"
这套流程，封装成一个名为 wiki-extract 的 Skill。
输入：一个主题词；输出：raw_material/ 原始资料 + wiki/ 结构化条目。
```
之后再写 wiki 就可以直接：`/wiki-extract` + 主题词，按同一套结构产出。

---

## Step 4：下载完整版 llm-wiki，用 Obsidian 打开（5 分钟）

自己从零建几条够熟悉流程；要看**完整版**知识库，下载课程准备好的包：

- 下载 `wealth-llm-wiki.zip`（课程材料里），解压
- 用 **Obsidian** 打开解压出的文件夹（Open folder as vault）
- 打开 **Graph View**，看 401K / RSU / ISO / 529 等节点的 `[[wiki-link]]` 关联图

> 没克隆/下载也行，可继续用自己 Step 1-3 生成的版本。

---

# Part 2 · 用武器赚钱（Skills 驱动客户服务 → 出 PPT，约 35 分钟）

## Step 5：装社区 Skills（5 分钟）

在 Claude Code 里：
```
/plugin install superpowers@superpowers
/plugin install ppt-master@ppt-master
```
装完即用，无需配置。`/brainstorming`、`/ppt-master` 可用即成功。

---

## Step 6：Brainstorm 王先生 → 建 `/wealth-client-qa` Skill（10 分钟）

### 方式 A：用 `/brainstorming`
```
/brainstorming
我是一名专注北美华人的财务顾问，有一个新客户：
王先生，42 岁，湾区华人工程师，有 RSU 税务、旧 401K 处理、529 起步等问题。
帮我做客户 brainstorm，把结果保存到 output/王先生/
```
Claude 会提问，你逐步回答，最终生成 `output/王先生/00-profile.md`。

### 方式 B：直接提示词（无 Skill 依赖）
```
请扮演财务顾问助手，帮我梳理新客户信息。
客户：王先生，42 岁，湾区华人工程师，已婚两孩。
收入：W2 约 $28 万 + RSU vest 约 $30 万。
旧公司 401K 约 $15 万未处理，两孩无 529，绿卡持有者。

请读取 wiki/ 目录下的知识条目，找出对这位客户最相关的议题，
生成客户画像（基本信息表、五大目标诊断、最相关的 wiki 条目），
保存到 output/王先生/00-profile.md
```

### 提取模板 + 建 Skill
```
根据王先生这个案例，从 output/王先生/00-profile.md 提取一份通用客户问答模板，
保存到 wiki/client-template.md。两层：
- 第一层（必问）：任何新客户都要问的 5-8 个基础问题
- 第二层（按主题深挖）：针对 RSU / ISO / 401K / 529 等的深挖问题
每个问题注明为什么要问。
```
```
请创建一个名为 wealth-client-qa 的 Skill。
用法：/wealth-client-qa <客户名> [--topic <主题>]

功能：
- 默认模式（/wealth-client-qa 李女士）：读取 wiki/client-template.md 第一层基础问题，
  逐一询问客户（每次 2-3 个问题），等用户回答后继续。
  收集完后判断 2-3 个核心议题，从 wiki/ 提取相关知识，
  生成客户画像保存到 output/<客户名>/00-profile.md。
- 深挖模式（/wealth-client-qa 李女士 --topic ISO）：针对指定主题，
  只问该主题的第二层深挖问题，补充进 output/<客户名>/。
```

> 备用：Skill 输出质量不够，把 `virtual-client-wang.md` 内容直接粘到 `output/王先生/00-profile.md` 继续。

---

## Step 7：新客户李女士——运行 `/wealth-client-qa`（10 分钟）

### 方式 A：有 Skill
```
/wealth-client-qa 李女士
```
按提示回答李女士情况：35 岁，绿卡 5 年，单身，年薪 $18 万 + ISO 期权，3 个月后满 Cliff。
（识别出核心议题 ISO 后，可再跑 `/wealth-client-qa 李女士 --topic ISO` 深挖。）

### 方式 B：直接提示词
```
请读取 wiki/client-template.md 的第一层基础问题，
逐一询问我（我扮演客户李女士），每次问 2-3 个，等我回答后继续。
收集完后判断 2-3 个核心议题，从 wiki/ 提取相关知识，
生成客户画像保存到 output/李女士/00-profile.md
```
参考回答：35 岁 / 绿卡 5 年 / 单身；$18 万 + ISO 5000 股行权价 $8，Cliff 3 个月后；无旧 401K / 无 IRA / 无保险 / 应急金 12 个月；最关心身份稳定下的灵活规划。

> 备用：Skill 出错，把 `virtual-client-li.md` 粘到 `output/李女士/00-profile.md` 继续。

---

## Step 8：ppt-master 为李女士生成专属 PPT（10 分钟）

```
/ppt-master
```
**输入提示词：**
```
请读取 output/李女士/00-profile.md，选取最核心的议题（ISO 期权），
为李女士生成一份专题 PPT：
- 第一页：客户 profile（基本情况 + 核心需求）
- 中间 3-4 页：ISO 期权分析与建议（AMT 风险、83(b) election、行权时机）
- 最后一页：李女士明天可以做的 3 件事
- 语言通俗，中文
保存到 output/李女士/
```
等待 5-10 分钟，用 PowerPoint 打开生成的 `.pptx` 验收。

---

## 验收标准

- [ ] `raw_material/` 下有分类子目录 + README
- [ ] `wiki/` 下有至少 1 篇 wiki 条目；`/wiki-extract` Skill 已建
- [ ] `wiki/client-template.md` 存在且有结构化问题列表
- [ ] `output/王先生/00-profile.md` 存在，含五大目标诊断
- [ ] `output/李女士/00-profile.md` 存在，含 ISO 期权核心议题
- [ ] `output/李女士/` 下有可打开的 `.pptx`

全部通过后，进入 `homework-guide.md`，换成你自己的领域走六步。

---

## 常见问题

**Q：Skill 安装失败？**

先确认 Claude Code 版本较新。`/plugin install` 报错时，可改用各步"方式 B"的纯提示词版本完成全流程。

**Q：wiki 内容搜索不到？**

Claude Code 有 WebSearch，但需要网络。搜索失败可先手动从 IRS.gov / Investopedia 复制文本粘进对话，再让 Claude 整理成 wiki 格式。

**Q：ppt-master 一直在跑，没有输出？**

正常，5-10 分钟是正常时间，看到 `[Done] Saved:` 才算完成。超过 15 分钟无响应再检查报错、重新触发。

**Q：生成的 PPT 内容不对或格式乱？**

先检查 `output/李女士/00-profile.md` 是否够具体。内容越具体（有数字、有具体问题），PPT 质量越高。可手动编辑 profile 后重跑。
