# Session 2 作业

## 作业结构

```
homework/
├── README.md          ← 你在这里
├── homework-guide.md  ← 主作业指南（六步，必读）
└── demo/
    ├── virtual-client-wang.md  ← 王先生客户备用画像（演示练习用）
    ├── virtual-client-li.md    ← 李女士客户备用画像（演示练习用）
    └── test-run.md             ← 走通今天演示的完整操作步骤（学员版）
```

## 两个部分

**Part A — 走通演示（不用提交）**

按 `demo/test-run.md` 的步骤，从空目录开始，把今天的财务顾问演示自己跑一遍：建库 + `/wiki-extract` + `/wealth-client-qa` + `/ppt-master`。验证环境正常、流程熟悉。

某步 Skill 输出质量不够，可用 `demo/virtual-client-wang.md` 或 `virtual-client-li.md` 直接粘贴继续。

**Part B — 换成自己的领域（需要提交）**

选一个你有领域知识的行业，按 `homework-guide.md` 的**六步**走一遍：选领域 → 建三层目录 → 先建 `/wiki-extract` 写 3 篇 wiki → 用 superpowers 做客制化方案 → `/ppt-master` 出 PPT →（进阶）封装客户咨询 Skill。

## 提交方式

发邮件至 **austin.aicourse@gmail.com**，主题：**【Session 2 作业】+ 你的名字**

**三样都要：** ① 3 篇 wiki 片段　② `/ppt-master` 生成的 PPT 截图　③ 200 字心得。

详见 `homework-guide.md` 末尾。
