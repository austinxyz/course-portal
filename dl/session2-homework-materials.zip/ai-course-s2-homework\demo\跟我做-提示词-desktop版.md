# 跟我做 · Session 2 演示原始提示词（Desktop 版）

> **Desktop 版 = 全程不用终端。** 建文件夹用文件管理器，开 Claude Code 用桌面应用，提示词和原版完全一样。

> 你照顺序、一条一条复制粘贴，就能跟着一起把知识库建出来、再用它服务客户、出 PPT。
> 两段：**第一段 建武器**（建北美华人理财知识库）→ **第二段 用武器赚钱**（Skills 驱动客户服务 → ppt-master 出 PPT）。

---

## 开跑前准备（课前已装好）

1. **Claude Code 桌面应用**已装好并登录
2. **superpowers + ppt-master** 已装（`/brainstorming`、`/ppt-master` 可用）
3. **Obsidian** 已装好

### 第 0 步 · 建项目文件夹（不用终端）

**Windows：**
1. 打开**文件资源管理器**（Win + E）
2. 进入「文档」或桌面，右键 → 新建 → 文件夹
3. 命名为 `wealth-demo`（名字随意，找得到就行）

**Mac：**
1. 打开 **Finder**
2. 进入「文稿」或桌面，右键 → 新建文件夹
3. 命名为 `wealth-demo`

### 第 0.5 步 · 在 Claude Code 桌面应用中打开这个文件夹

1. 打开 **Claude Code 桌面应用**
2. 点击 **「Open Folder」** 或 **「打开文件夹」**（首页或菜单栏 File → Open Folder）
3. 选刚才建的 `wealth-demo` 文件夹
4. 确认左下角或标题栏显示的是 `wealth-demo` 这个路径

> ⚠️ **一个项目一个文件夹，全程在这个文件夹里跑。** 后面创建的 Skill（`/wiki-extract`、`/wealth-client-qa`）存在这个项目的 `.claude/` 下，只能在同一个文件夹打开 Claude Code 才用得到。

---

# 第一段 · 建武器（建理财知识库）

## 第 1 步 · 初始化项目 + CLAUDE.md

> 👉 **这步在干嘛**：让 AI 一句话搭好三层目录骨架——先有项目结构，后面才好往里装东西。

```
请帮我初始化一个北美华人个人理财知识库项目。
参考 LLM Wiki 方法论，创建三层目录结构：
- raw_material/：原始素材区
- wiki/：结构化知识库
- output/：客户档案区（隐私区，不进 Git）

同时创建 CLAUDE.md，说明项目结构和隐私规则
（output/ 下的客户数据不进 Git，加入 .gitignore）。
```

---

## 第 2 步 · 生成 raw_material/ 骨架

> 👉 **这步在干嘛**：让 AI 规划知识库分类——先把货架搭好，再往上摆知识。

```
请为这个北美华人个人理财知识库规划 raw_material/ 的分类结构。
在 raw_material/ 下创建子目录，每个子目录创建 README.md，
列出该分类下建议收录的知识条目清单。
```

预期：`retirement/`、`tax/`、`education/`、`insurance/` 等子目录，各含 README。

---

## 第 3 步 · 搜索第一条 wiki（401K，手动跑一遍）

> 👉 **这步在干嘛**：手动走一遍「搜原始资料 → 提炼成 wiki」，摸清流程——下一步才好把它封装成 Skill。

```
请读取 raw_material/retirement/README.md，从清单里挑「401K rollover」这一条，
搜索相关权威信息：
1. 把原始内容（含来源链接）保存到 raw_material/retirement/
2. 提炼成一篇 wiki 条目，保存到 wiki/retirement/401k-rollover.md

wiki 结构：概述 → 核心要点 → 常见误区 → 相关条目
```

---

## 第 4 步 · 现场 Review，加入我的领域判断

> 👉 **这步在干嘛**：把你的实战经验补进 AI 写的 wiki——这一步是灵魂，让它变成**你的系统**，不只是 AI 的系统。

```
这篇 401K rollover 的 wiki 我读了，有几处要补我的实战经验：
- 加一条常见误区：很多人 60 天 indirect rollover 忘了 20% 预扣，导致补税
- 适用场景里补一句：换工作时旧 401K 留在前雇主 vs. rollover 到 IRA 的权衡
请把这两点补进 wiki/retirement/401k-rollover.md，保持原结构。
```

---

## 第 5 步 · 顺手把提取流程封装成 /wiki-extract Skill

> 👉 **这步在干嘛**：把刚才手动跑的流程封装成 Skill——以后再写 wiki 一句话搞定，每篇都按同一套结构走。

```
请把刚才「搜索原始资料 → 存 raw_material/ → 提炼成 wiki 条目存 wiki/」
这套流程，封装成一个名为 wiki-extract 的 Skill。
输入：一个主题词；输出：raw_material/ 原始资料 + wiki/ 结构化条目
（概述 → 核心要点 → 常见误区 → 适用场景），并提示我 Review 补充领域判断。
```

封装好后，再写 wiki 就一句话：

```
/wiki-extract
主题：RSU vesting 与税务
```

---

## 第 6 步 · 下载完整版 llm-wiki，用 Obsidian 看（操作，非提示词）

> 👉 **这步在干嘛**：看「跑了 20 篇之后」的完整知识库长啥样——感受 `[[wiki-link]]` 把知识连成网。

1. 下载 `wealth-llm-wiki.zip`（课程材料），解压到任意位置
2. 打开 **Obsidian** → **Open folder as vault** → 选解压出的文件夹
3. 打开 **Graph View**，看 401K / RSU / ISO / 529 节点的 `[[wiki-link]]` 关联图

> 💡 找不到你建的 Skill？`.claude/` 这类「点开头」的文件夹 Obsidian 默认不显示——想看 Skill 文件，在 Claude Code 桌面应用左侧文件树中点「显示隐藏文件」，或去系统文件管理器开启「显示隐藏文件」。Obsidian 只用来看知识网（`wiki/`）。

---

# 第二段 · 用武器赚钱（客户服务 → 出 PPT）

> 切换到完整版知识库目录（下载的 wealth-llm-wiki）：Claude Code 桌面应用 → File → Open Folder → 选 wealth-llm-wiki 文件夹。下面都在它里面跑。

## 第 7 步 · Brainstorm 王先生（superpowers）

> 👉 **这步在干嘛**：用 superpowers 跟客户对话、理清最关键的议题、生成客户画像——知识库开始服务真人。

```
/brainstorming
我是一名专注北美华人的财务顾问，有一个新客户：
王先生，42 岁，湾区华人工程师，已婚两孩，绿卡持有者。
收入 W2 约 $28 万 + RSU vest 约 $30 万；旧公司 401K 约 $15 万未处理；两孩无 529。
帮我做客户 brainstorm，理清他最关键的 2-3 个议题，
生成客户画像保存到 output/王先生/00-profile.md
```

> 💬 **Claude 会反问你问题**——这是 `/brainstorming` 的正常节奏，不是报错。照上面王先生的信息回答即可；问到没给的细节，随便补一个合理答案，或直接回「跳过，按你的判断继续」。

---

## 第 8 步 · 从这个案例提取通用客户问答模板

> 👉 **这步在干嘛**：从一个真实案例抽象出可复用的问答模板——下一个客户就照这套问。

```
根据王先生这个案例，从 output/王先生/00-profile.md 提取一份通用客户问答模板，
保存到 wiki/client-template.md。两层：
- 第一层（必问）：任何新客户都要问的 5-8 个基础问题
- 第二层（按主题深挖）：针对 RSU / ISO / 401K / 529 等的深挖问题
每个问题注明为什么要问。
```

---

## 第 9 步 · 把问答流程封装成 /wealth-client-qa Skill

> 👉 **这步在干嘛**：把问答流程封装成 Skill——新客户一键收集，改了模板它就是你的系统。

```
请创建一个名为 wealth-client-qa 的 Skill。
用法：/wealth-client-qa <客户名> [--topic <主题>]

功能：
- 默认模式（/wealth-client-qa 李女士）：第一次见面。读取 wiki/client-template.md
  的第一层基础问题，逐一询问客户（每次 2-3 个问题），等用户回答后继续。
  收集完后判断 2-3 个核心议题，从 wiki/ 提取相关知识，
  生成客户画像保存到 output/<客户名>/00-profile.md。
- 深挖模式（/wealth-client-qa 李女士 --topic ISO）：针对指定主题，
  只问该主题的第二层深挖问题，把结果补充进 output/<客户名>/。
```

---

## 第 10 步 · 新客户李女士，跑 /wealth-client-qa

> 👉 **这步在干嘛**：用刚封装的 Skill 跑一个全新客户，验证模板真能复用。

```
/wealth-client-qa 李女士
```

按提示回答李女士情况（课上现场回答）：
- 35 岁 / 绿卡 5 年 / 单身
- 年薪 $18 万 + ISO 期权 5000 股，行权价 $8，Cliff 3 个月后满
- 无旧 401K / 无 IRA / 无保险 / 应急金 12 个月
- 最关心：身份稳定下的灵活规划

→ 自动识别核心议题（ISO 期权）→ 生成 `output/李女士/00-profile.md`。

---

## 第 10.5 步 · （可选）深挖 ISO 专题

> 👉 **这步在干嘛**：同一个 Skill 的深挖模式，只针对核心议题（ISO）追问——为 PPT 攒专题素材。
>
> 📖 **ISO = Incentive Stock Options（激励型股票期权）**：公司给员工的一种期权，可在未来按固定「行权价」买入公司股票。

```
/wealth-client-qa 李女士 --topic ISO
```

> 💬 它会逐个问 ISO 细节，照下表填：
>
> | Claude 可能问 | 照填 |
> |---|---|
> | ISO 授予总量？vesting 时间表？ | 5000 股，标准 1 年 cliff + 4 年线性 |
> | 行权价？最近一次 409A 估值？ | 行权价 $8；409A 约 $8（AMT 暴露小） |
> | 公司有 ESPP 吗？ | 没有 |

---

## 第 11 步 · ppt-master 为李女士出专属 PPT

> 👉 **这步在干嘛**：读客户档案，一键出专属 PPT——原始资料 → 知识库 → 客户服务 → 成品，闭环完成。
>
> ⚠️ **跑前先 `/clear`**——ppt-master 耗 token 多，清空上下文避免超限。

```
/ppt-master
```

```
请读取 output/李女士/ 下的客户画像和问题答案文件，
选取最核心的议题——ISO（Incentive Stock Option），
为李女士生成一份专题 PPT：
- 第一页：客户 profile（基本情况 + 核心需求）
- 中间 3-4 页：ISO 期权分析与建议（AMT 风险、83(b) election、行权时机）
- 最后一页：李女士明天可以做的 3 件事
- 语言通俗，中文
保存到 output/李女士/
```

等 5-10 分钟，用 PowerPoint 打开生成的 `.pptx` 验收。

---

> **全程闭环**：原始资料 → /wiki-extract 建知识库 → /wealth-client-qa 收集客户 → ppt-master 出材料。
> 课后作业把这套搬到**你自己的领域**——见 `homework/homework-guide.md`。
