# Post-Class Practice Guide
## Turning Session 2 Into a Skill You Actually Own

What you saw in Session 2 was this: **build a knowledge base from an empty directory, then use it to serve a client and produce a PPT.**

But **understanding it isn't the same as being able to do it.** The real skill comes from moving this workflow into **a domain where you have your own knowledge** and walking through it yourself. Do the four steps below in order, and don't skip the "write down what you learned" part of any of them — that's the soul of the whole method.

---

## Step 0 · Set up your learning workspace

Open Claude Code and create an **empty directory** for your course project (something like `my-ai-course-s2`). Empty is correct — everything in it will grow out of your work with the AI.

Suggested structure (build it as you go, no need to do it all at once):

```
my-ai-course-s2/
├── course-notes/
│   ├── ppt/                     # put the class slides here
│   ├── follow-along-prompts.md  # the demo prompt list from the download pack
│   ├── my-notes.md              # scratch — write whatever comes to mind
│   ├── unclear-terms.md         # terms and concepts you didn't catch
│   └── course-summary.md        # have the AI generate this one
└── knowledge-base/              # your own domain's knowledge base (the homework — see Step 3)
    ├── raw_material/
    ├── wiki/
    └── output/
```

> 💡 **Nervous about `.md`? `.txt` works just as well.** If Markdown feels like a hassle, make all of those files `.txt` instead — Notepad or TextEdit will do. The AI reads them and summarizes them exactly the same. `.md` only gives you nicer formatting. Don't let file extensions stop you from starting.

---

## Step 1 · Write your own notes, then have the AI expand them

**You write first, then the AI fills in.** The order matters — the AI is there to deepen your thinking, not to remember class for you.

1. In `my-notes.md`, recall as much of the class as you can and write down your takeaways. **It doesn't have to be polished** — fragments and half-sentences are fine.
2. In `unclear-terms.md`, note the terms and concepts you didn't fully follow (raw_material / wiki / Skill / Graph View, and so on).
3. Put the slides in the `ppt/` folder. Then put **`follow-along-prompts.md`** from the download pack into `course-notes/` too — it's the **prompt list** used in the live demo, with a note on each step explaining what it's doing. When the AI reads it, it can reconstruct each step accurately.
4. Then ask the AI to combine your notes, the slides, and `follow-along-prompts.md` into a summary. **Ask several times**, going deeper each round, and finish by asking it to **write out a `course-summary.md` file** you can come back to later.

> 📎 **Why `follow-along-prompts.md` matters**: the slides tell you *what was discussed*; `follow-along-prompts.md` tells you *which prompts were actually sent*. When a step didn't land or you can't remember a detail from the demo, having the AI consult `follow-along-prompts.md` gives you a far more accurate answer than having it explain from scratch.

**Example prompts** (copy them, then make them your own):

```
Using my notes (my-notes.md), the slides (files in ppt/), and follow-along-prompts.md,
help me summarize this class and save it to course-summary.md.
```

```
I didn't follow the "___" step in the demo. Using follow-along-prompts.md,
explain clearly what that step was doing and why it was done that way.
```

```
What are raw_material/, wiki/, and output/ each for? Why split them this way?
Add the answer to my summary.
```

```
What actually is a Skill? How is it different from just typing a prompt?
Explain it in plain language with examples, and add it to my summary.
```

---

## Step 2 · Run the class demo yourself (Part A)

**You only really get it by doing it.** Using `demo/follow-along-prompts.md` from the download pack, start from an **empty directory** and run today's financial advisor demo yourself: build the three-layer knowledge base → `/wiki-extract` writes your first wiki entry → `/wealth-client-qa` collects the client → `/ppt-master` produces the PPT. About 30–40 minutes.

- **Improvise freely** — the AI is forgiving, and getting things wrong is fine.
- If a Skill's output isn't good enough at some step, paste in `demo/virtual-client-wang.md` or `virtual-client-li.md` and keep moving.
- As you go, keep adding your takeaways, the things that tripped you up, and the moments something clicked to `course-notes/my-notes.md`, and have the AI keep folding them into the summary.

Part A is just for building intuition and verifying your setup — **nothing to submit.** What you actually turn in is Part B (Step 3).

---

## Step 3 · Redo it in your own domain (Part B)

Homework isn't about checking a box — it's about **moving this workflow into a domain where you have real knowledge**, one where you can tell whether the AI's output is right. Insurance, law, healthcare, education, real estate all work. If you genuinely don't have one, follow along with the wealth management version.

**The full six steps are in `homework-guide.en.md`.** Here's the skeleton:

| Step | What you do | Submit? |
|------|-------------|---------|
| Step 1-2 | Choose your domain + build the three-layer directory (`raw_material/ wiki/ output/` + CLAUDE.md) | — |
| **Step 3** | Build the `/wiki-extract` Skill first, use it to write **3 wiki entries**, reviewing each one and adding your industry judgment | **Yes** |
| Step 4 | Use superpowers (`/brainstorming`) to build a tailored plan for one specific client/scenario | — |
| **Step 5** | Use `/ppt-master` to produce a PPT — keep a screenshot | **Yes** |
| Step 6 ★ | (Advanced, optional) package a client consultation Skill for your domain | No |

**Iteration is the point.** If the quality isn't there, improve the plan/profile in `output/` first, then re-run. **Knowledge base quality > prompt technique.** The single most important step is Step 3d: **after each wiki entry, add the industry experience the AI missed.** That's what turns it from "the AI's system" into "your system."

**Prompt to build the three-layer directory** (run it in a new empty directory with Claude Code open):

```
Please initialize a [your domain] knowledge base project, organized in three layers:
raw_material/ (raw sources, keep the links), wiki/ (structured knowledge entries),
output/ (client files — private, not in Git).
Create those three directories plus a CLAUDE.md describing the structure and
privacy rules, and add output/ to .gitignore.
```

---

## Step 4 · Have the AI write me an email = submitting your homework

Finally, combining **what you learned** and **what you produced**, have the AI write me an email.

> 📌 **Important**: this email **is** your homework submission — all three items below are required, none can be dropped. Letting the AI write it doesn't mean letting the AI skip things. Spell all three out in your prompt and make it fill in each one.

**Three items (all must appear in the email body):**

1. **3 wiki excerpts** — paste in the content of the 3 wiki entries you wrote in Step 3 (or screenshots), ideally with the industry judgment you added yourself.
2. **A screenshot of the PPT `/ppt-master` generated** — 1–2 key slides from the Step 5 deck.
3. **A 200-word reflection** — how did this feel different from the Session 1 homework? Some prompts: What's the difference between a "tool" and a "system"? Where did the AI's answer make you want to change or add something? If you had real clients in this domain, how would you use this workflow? (200+ words, no upper limit.)

**Example prompt** (copy it, swap in your own paths):

```
Using my knowledge base project (the knowledge-base/ directory) and my course notes
(the course-notes/ directory), help me write an email to my instructor submitting
my homework. All three items below must appear in full in the email body — do not
skip any of them:
1. The 3 wiki entries I wrote in Step 3: paste the content as-is, marking the
   industry judgment I added myself;
2. The Step 5 PPT: say what domain it's in and which client/scenario it was built
   for (I'll attach the screenshot separately);
3. My reflection: 200+ words, covering my take on "tool vs. system" and where I
   changed or added to the AI's output.
End with a paragraph on what I'm still confused about. Sincere, concise tone.
When you're done, list a checklist and verify none of the three items are missing.
```

**How to send**: email `austin.aicourse@gmail.com` with the subject **[Session 2 Homework] + Your Name**.

I'm not looking for perfection — I want to see that **you actually did it and actually thought about it.** Confusion and sticking points are especially welcome; those are exactly what I can help with next session.

---

> **In one line**
> Write your notes → have the AI summarize → run the demo yourself → rebuild it in your own domain and produce a PPT → send it to me.
> Do every step by hand, and leave a record at every step. The skill this course teaches is built by *doing*, not by *listening*.

—— Stuck on any step? Screenshot it in the study group. Your instructor and classmates will help. There are no dumb questions.
