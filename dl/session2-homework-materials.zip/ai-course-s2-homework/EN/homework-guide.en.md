# Session 2 Homework Guide

> Goal: take today's demo flow and apply it to **a domain where you have real knowledge** — and verify it actually works.
> Six steps, complete them this week.

---

## Step Overview

| Step | Content | Submit? |
|------|---------|---------|
| Step 1 | Choose your domain | — |
| Step 2 | Build the three-layer directory structure | — |
| Step 3 | Create `/wiki-extract` Skill, write 3 wiki entries | **Yes** (submit wiki excerpts) |
| Step 4 | Use superpowers for a customized plan | — |
| Step 5 | Use `/ppt-master` to generate a PPT | **Yes** (submit PPT screenshot) |
| Step 6 ★ | Package a client consultation Skill (advanced, optional) | No |

> Before starting, follow `demo/follow-along-prompts.md` to run through the demo once (the financial advisor demo, about 30–40 minutes) — prompts are in order, each with a note on what it's doing, just copy and paste. Confirm your environment works and the flow makes sense, then switch to your own domain.

---

## Step 1: Choose Your Domain

**Pick a domain where you have real expertise** — somewhere you can tell whether the AI's output is right or wrong. Insurance / law / healthcare / education all work. If you genuinely don't have domain expertise, follow along with the **wealth management knowledge base** (download `wealth-llm-wiki.zip` and see the [wealth guide tutorial](https://austinxyz.github.io/blogs/wealth-guide.html)).

| Domain example | Possible wiki entries |
|---------------|----------------------|
| Insurance | Term vs. whole life insurance / underwriting rules for critical illness / common claims pitfalls |
| Law (immigration) | H1B lottery mechanics / EB-1A application standards / RFE response strategy |
| Law (business) | Startup equity agreement key points / SAFE note vs. Convertible note / IP considerations |
| Healthcare | Common chronic disease management guides / insurance coverage and out-of-pocket calculations / referral process |
| Education consulting | College application timeline / Common App essay strategy / recommendation letter prep checklist |
| Real estate | Home buying process and timeline / 1031 Exchange basics / what title insurance actually does |
| Other | Any domain where you can judge output quality |

---

## Step 2: Build the Three-Layer Directory Structure

Open Claude Code in a new empty directory and use this prompt to set up the three-layer structure.

```
Please initialize a [your domain] knowledge base project.
Following the LLM Wiki method, organize with a three-layer directory structure:
- raw_material/: raw source area, for storing original research material (keep source links)
- wiki/: refined knowledge area, for structured knowledge entries
- output/: client files area (private, not in Git)

Create these three directories + a CLAUDE.md describing the project structure and privacy rules
(client data under output/ goes in .gitignore, not in Git).
```

**Expected result:** `raw_material/`, `wiki/`, `output/` directories + `CLAUDE.md` + `.gitignore` (containing `output/`).

---

## Step 3: Create `/wiki-extract` Skill, Write 3 Wiki Entries

**Package the "extraction flow" into a Skill first, then use it to produce wikis** — this way each entry follows the same structure and quality is consistent.

### 3a. Write the first wiki entry (manually, to understand the flow)

```
Please read the README in raw_material/, pick one topic, and search for authoritative information:
1. Save the raw content (with source links) to raw_material/
2. Then refine it into a wiki entry suitable for a knowledge base, save to wiki/

Wiki structure: Overview → Key Points → Common Misconceptions → Use Cases
```

### 3b. Package this flow as a `/wiki-extract` Skill

```
Please take the flow we just did — "search raw material → save to raw_material/ → refine into wiki entry saved to wiki/" —
and package it as a Skill named wiki-extract.
Input: a topic keyword; Output: raw_material/ original source + wiki/ structured entry (Overview → Key Points → Common Misconceptions → Use Cases).
```

### 3c. Use `/wiki-extract` to write 2 more entries, reaching 3 total

```
/wiki-extract
Topic: [a second specific question in your domain]
```

> **Only 3 entries needed — quality over quantity.** One entry that thoroughly covers a specific question is worth more than ten shallow entries.

### 3d. Add your own judgment (important)

After each entry, **read it yourself and add your professional experience**:
- Real situations from your actual work that the AI didn't mention?
- Questions clients often ask where the AI's answer isn't quite right?
- Risks worth flagging that the AI skipped by default?

This step is what makes it **your system**, not just the AI's.

---

## Step 4: Use Superpowers for a Customized Plan

For **one specific client / scenario**, use superpowers (`/brainstorming` + plan) to produce a tailored plan.

```
/brainstorming
I'm a [your domain] consultant with a specific client / scenario: [one sentence description — the more specific, the better — age, background, core pain point / need].
Based on the knowledge in wiki/, help me brainstorm, identify the 2–3 most critical issues for this client,
and produce a customized plan (save to output/<client-name>/).
```

> No real client needed. The more specific your fictional profile (with numbers, specific pain points), the better the output.

---

## Step 5: Use `/ppt-master` to Generate a PPT

Using **the wiki + plan** as source material, generate a presentation for a client or colleague.

```
/ppt-master
```

```
Please read the plan and profile under output/<client-name>/, select the most critical issues,
and generate a focused PPT for this client, saved to output/<client-name>/.

PPT requirements:
- First slide: client profile (background + core needs)
- Middle 3–5 slides: analysis and recommendations on the core issues
- Last slide: 3 things the client can do tomorrow
- Plain language, in English
```

**Wait about 5–10 minutes** (ppt-master generates multiple SVG pages then converts to PPTX). Once done, open in PowerPoint / Keynote to review, **take a screenshot to submit**.

> If quality isn't good enough, improve the plan / profile under `output/<client-name>/` first, then re-run. Knowledge base quality > prompt technique.

---

## Step 6 (Advanced, Optional): Package a Client Consultation Skill

Package the "simulate client → collect info → generate profile" flow as your own domain-specific Skill (modeled on `/wealth-client-qa` from the demo):

```
Please create a Skill named /[your-domain]-client-qa.
Function: read wiki/client-template.md,
ask the client 2–3 questions at a time to gather basic information, then identify 2–3 core issues,
pull relevant knowledge from wiki/, and generate a client profile saved to output/<client-name>/00-profile.md.
```

You can share your Skill with the group next session.

---

## Submission Requirements

Email to **austin.aicourse@gmail.com**, subject must be: **[Session 2 Homework] + Your Name**

**Three items, all required:**

1. **3 wiki excerpts** — paste the content of the 3 wiki entries you wrote in Step 3 into the email (or screenshots).
2. **ppt-master PPT screenshot** — screenshot of the PPT from Step 5 (1–2 key slides is enough).
3. **200-word reflection** — how is this experience different from Session 1? You can use these as prompts:
   - What's the difference between a "tool" and a "system"?
   - Where did the AI give an answer you felt you needed to correct or add to?
   - If you have real clients in this domain, how would you use this workflow?

(200+ words, no upper limit)

---

## FAQ

**Q: I'm not in the financial industry — does this workflow still apply to me?**

Yes. Today's pattern — raw sources → knowledge base → client service → output document — works for any domain where you need to explain professional concepts to clients.

**Q: How many knowledge base entries do I need before it's useful?**

3 is enough. Get it running first, then expand. The value of a knowledge base is in its structure, not its quantity.

**Q: What if I haven't installed the Skills?**

You can complete every step with plain prompts — just replace `/wiki-extract`, `/wealth-client-qa` and similar Skill calls with a direct prompt describing what you want. The `demo/follow-along-prompts.md` Step 3 shows the manual version without Skills.

**Q: `/ppt-master` is taking too long — is something wrong?**

Normal. Generating a 5–8 page PPT takes about 5–10 minutes. Feel free to do something else while you wait.
