# Session 2 Homework

## Structure

```
homework/
├── README.md          ← you are here
├── homework-guide.en.md  ← main homework guide (six steps, required reading)
└── demo/
    ├── virtual-client-wang.md   ← Mr. Wang client profile (for demo practice)
    ├── virtual-client-li.md     ← Ms. Li client profile (for demo practice)
    └── follow-along-prompts.md   ← prompt checklist from the demo, copy in order (each step has a note)
```

## Two Parts

**Part A — Walk Through the Demo (no submission)**

Follow the prompts in `demo/follow-along-prompts.md` and run today's financial advisor demo from scratch on your own: build the knowledge base + `/wiki-extract` + `/wealth-client-qa` + `/ppt-master`. This confirms your environment works and the flow makes sense.

If a Skill's output quality isn't what you expected at some step, use `demo/virtual-client-wang.md` or `virtual-client-li.md` to paste in and keep going.

**Part B — Apply It to Your Own Domain (submit this)**

Pick a domain where you have real knowledge, then follow the **six steps** in `homework-guide.en.md`: choose your domain → build the three-layer directory → create `/wiki-extract` and write 3 wiki entries → use superpowers for a customized plan → generate a PPT with `/ppt-master` → (advanced) package a client consultation Skill.

## How to Submit

Email to **austin.aicourse@gmail.com**, subject: **[Session 2 Homework] + Your Name**

**Three items required:** ① 3 wiki excerpts　② `/ppt-master` PPT screenshot　③ 200-word reflection.

See the end of `homework-guide.en.md` for details.
