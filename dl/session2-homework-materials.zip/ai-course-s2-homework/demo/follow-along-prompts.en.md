# Follow Along · Session 2 Demo Prompts

> These are the exact prompts I type during class. **Copy and paste them one at a time, in order**, and you'll build the knowledge base alongside me, then use it to serve a client and produce a PPT.
> Two halves: **Part One — build the weapon** (a personal finance knowledge base for Chinese Americans) → **Part Two — put the weapon to work** (Skills-driven client service → ppt-master generates the PPT).
>
> **Before you start (should already be done from the pre-class setup):**
> 1. Claude Code installed, `claude` launches and you're logged in
> 2. superpowers + ppt-master installed (`/brainstorming` and `/ppt-master` both work)
> 3. Obsidian installed
> 4. A new empty directory as your project root, with Claude Code opened inside it
>    - 📁 **Where should the directory go?** Somewhere you can actually **find it** — `Documents/wealth-demo` works well (visible in Finder/File Explorer). In class I use `~/projects/wealth-demo`; the `~` means "home directory," which is a hidden path on Windows and annoying to locate. Don't feel obliged to copy me.
>    - ⚠️ **One project, one directory — stay in it the whole time.** The Skills you create later (`/wiki-extract`, `/wealth-client-qa`) live under this project's `.claude/` folder, so **they only work when you launch Claude Code from this directory**. Switch directories and `/skill` won't find them — just `cd` back to the project in your terminal and restart `claude`.

---

# Part One · Build the Weapon (a personal finance knowledge base)

## Step 1 · Initialize the project + CLAUDE.md

> 👉 **What this step does**: gets the AI to scaffold a three-layer directory structure in one shot. Structure first — everything else goes inside it.

```
Please initialize a personal finance knowledge base project for Chinese Americans.
Following the LLM Wiki method, create a three-layer directory structure:
- raw_material/: raw source area
- wiki/: structured knowledge base
- output/: client files area (private, not in Git)

Also create a CLAUDE.md describing the project structure and privacy rules
(client data under output/ stays out of Git — add it to .gitignore).
```

---

## Step 2 · Generate the raw_material/ skeleton

> 👉 **What this step does**: has the AI plan the knowledge categories. Build the shelves first, then stock them.

```
Please plan the category structure for raw_material/ in this personal finance
knowledge base for Chinese Americans.
Create subdirectories under raw_material/, each with a README.md that lists
the knowledge entries worth collecting in that category.
```

Expected: subdirectories like `retirement/`, `tax/`, `education/`, `insurance/`, each with a README.

---

## Step 3 · Research your first wiki entry (401K, done manually)

> 👉 **What this step does**: walks the "research raw sources → distill into a wiki entry" loop by hand so you understand it. You can't package a process into a Skill until you've felt it.

```
Please read raw_material/retirement/README.md, pick "401K rollover" from the list,
and research authoritative information on it:
1. Save the raw content (with source links) to raw_material/retirement/
2. Distill it into a wiki entry saved to wiki/retirement/401k-rollover.md

Wiki structure: Overview → Key Points → Common Misconceptions → Related Entries
```

---

## Step 4 · Review it live, add your own professional judgment

> 👉 **What this step does**: folds your real-world experience into what the AI wrote. This is the soul of the method — it's what turns it into **your system** instead of the AI's.

```
I've read the 401K rollover wiki entry and want to add some field experience:
- Add a common misconception: people doing a 60-day indirect rollover often forget
  the mandatory 20% withholding, and end up owing tax
- Add to the use cases: the tradeoff between leaving an old 401K with a former
  employer vs. rolling it over to an IRA when changing jobs
Please work both points into wiki/retirement/401k-rollover.md, keeping the existing structure.
```

---

## Step 5 · Package the extraction flow into a /wiki-extract Skill

> 👉 **What this step does**: turns the process you just ran by hand into a Skill. From now on, writing a wiki entry is one line, and every entry follows the same structure.

```
Please take the flow we just did — "research raw sources → save to raw_material/ →
distill into a wiki entry saved to wiki/" — and package it as a Skill named wiki-extract.
Input: a topic keyword. Output: raw source material in raw_material/ + a structured
entry in wiki/ (Overview → Key Points → Common Misconceptions → Use Cases),
and a prompt reminding me to review it and add my own domain judgment.
```

Once it's packaged, writing a new entry is a single line:

```
/wiki-extract
Topic: RSU vesting and taxes
```

---

## Step 6 · Open the full llm-wiki in Obsidian (hands-on, no prompt)

> 👉 **What this step does**: shows you what the knowledge base looks like after 20 entries — and how `[[wiki-link]]` weaves the knowledge into a network.

- Download `wealth-llm-wiki.zip` (course materials) and unzip it
- Obsidian → **Open folder as vault** → select the unzipped folder
- Open **Graph View** and look at the `[[wiki-link]]` connections between the 401K / RSU / ISO / 529 nodes
- This is what the knowledge base looks like after 20 entries

> 💡 Can't find the Skill you built? **Obsidian hides dot-folders like `.claude/` by default.** To look at Skill files, use VS Code or your system file manager (with "show hidden files" turned on). Obsidian is for browsing the knowledge network (`wiki/`) — it and VS Code are just looking at different parts of the same folder.

---

# Part Two · Put the Weapon to Work (client service → PPT)

> Switch to the full knowledge base directory (the wealth-llm-wiki you downloaded). Everything below runs inside it.

## Step 7 · Brainstorm Mr. Wang (superpowers)

> 👉 **What this step does**: uses superpowers to talk through a client, surface the issues that actually matter, and generate a client profile. The knowledge base starts serving a real person.

```
/brainstorming
I'm a financial advisor focused on Chinese Americans, and I have a new client:
Mr. Wang, 42, a Bay Area engineer, married with two children, green card holder.
Income: roughly $280K W2 + about $300K in RSU vesting. About $150K sitting in an old
employer's 401K, untouched. Two kids, no 529 accounts.
Help me brainstorm this client, identify his 2-3 most critical issues,
and generate a client profile saved to output/Wang/00-profile.md
```

Claude will ask questions; answer them step by step → it generates `output/Wang/00-profile.md`.

> 💬 **Claude will ask you questions back** (income, pain points, green card vs. H1B…) — that's `/brainstorming` working normally, not an error. Answer using Mr. Wang's details above. If it asks about something not covered above, make up something reasonable, or just reply "skip that, use your judgment and keep going." **Don't freeze up the moment it asks you something.**

---

## Step 8 · Extract a reusable client questionnaire from this case

> 👉 **What this step does**: abstracts a reusable template out of one real case. The next client gets asked the same way.

```
Based on the Mr. Wang case, extract a general client questionnaire template from
output/Wang/00-profile.md and save it to wiki/client-template.md. Two tiers:
- Tier 1 (always ask): the 5-8 baseline questions for any new client
- Tier 2 (topic deep-dives): follow-up questions for RSU / ISO / 401K / 529 and so on
Note why each question matters.
```

---

## Step 9 · Package the questionnaire flow into a /wealth-client-qa Skill

> 👉 **What this step does**: turns the intake flow into a Skill. New client, one command. And because you own the template, you own the system.

```
Please create a Skill named wealth-client-qa.
Usage: /wealth-client-qa <client name> [--topic <topic>]

Behavior:
- Default mode (/wealth-client-qa Li): first meeting. Read the Tier 1 baseline
  questions from wiki/client-template.md and ask the client one group at a time
  (2-3 questions per turn), waiting for answers before continuing.
  Once collected, identify 2-3 core issues, pull relevant knowledge from wiki/,
  and generate a client profile saved to output/<client name>/00-profile.md.
- Deep-dive mode (/wealth-client-qa Li --topic ISO): for the specified topic only,
  ask that topic's Tier 2 follow-up questions and add the results to output/<client name>/.
```

> Change the template and it becomes your system.

---

## Step 10 · New client Ms. Li — run /wealth-client-qa

> 👉 **What this step does**: runs the Skill you just built against a brand-new client, proving the template really is reusable.

```
/wealth-client-qa Li
```

Answer the prompts with Ms. Li's situation (I'll answer these live in class):
- 35 years old / green card for 5 years / single
- $180K salary + 5,000 ISO options, $8 strike price, cliff vests in 3 months
- No old 401K / no IRA / no insurance / 12 months of emergency savings
- Main concern: flexible planning now that her immigration status is settled

→ It identifies the core issue (ISO options) automatically → generates `output/Li/00-profile.md`.

---

## Step 10.5 · (Optional) Deep-dive on ISOs

> 👉 **What this step does**: same Skill, deep-dive mode, focused only on the core issue (ISOs) — gathering material for the PPT.
>
> 📖 **ISO = Incentive Stock Options**: options a company grants employees, letting them buy company stock later at a fixed "strike price." Deep-dive mode will ask you a few key ISO numbers — sample answers are below, just use those.

We've identified ISOs as Ms. Li's key issue, so use the same Skill's deep-dive mode to drill into ISOs only:

```
/wealth-client-qa Li --topic ISO
```

> 💬 **It asks about ISO details one at a time, generating each next question from your previous answer** — there's no right answer, just stay consistent with Ms. Li's setup. If it asks something you don't know, don't stop — use the table:
>
> | Claude might ask | Answer with |
> |---|---|
> | Total ISO grant? Vesting schedule? | 5,000 shares, standard 1-year cliff + 4-year linear vest |
> | Strike price? Most recent 409A valuation? | Strike $8; 409A around $8 (close together, so limited AMT exposure) |
> | Does the company offer an ESPP? | No |
>
> (ESPP = Employee Stock Purchase Plan.)

→ The ISO deep-dive answers get added to `output/Li/`, ready for the PPT in the next step.

---

## Step 11 · ppt-master builds a custom PPT for Ms. Li

> 👉 **What this step does**: reads the client file and produces a tailored deck in one command. Raw sources → knowledge base → client service → finished deliverable. The loop closes.

```
/ppt-master
```

```
Please read the client profile and question answers under output/Li/,
pick the single most critical issue — ISOs (Incentive Stock Options) —
and generate a focused PPT for Ms. Li:
- First slide: client profile (background + core needs)
- Middle 3-4 slides: ISO analysis and recommendations (AMT risk, 83(b) election, exercise timing)
- Last slide: 3 things Ms. Li can do tomorrow
- Plain language, in English
Save it to output/Li/
```

Wait 5-10 minutes, then open the generated `.pptx` in PowerPoint to review.

---

> **The full loop**: raw sources → `/wiki-extract` builds the knowledge base → `/wealth-client-qa` collects the client → ppt-master produces the deliverable.
> Your homework is to move this whole thing into **your own domain** — see `homework-guide.en.md`.
