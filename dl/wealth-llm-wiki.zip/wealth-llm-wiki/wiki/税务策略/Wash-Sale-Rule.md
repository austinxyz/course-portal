---
title: Wash Sale Rule
category: 税务策略
tags: [税务规则, IRS, 资本损失]
source: "[[raw_material/投资策略建议]]"
updated: 2026-04-16
status: stable
freshness: volatile
---

## 定义
Wash Sale Rule（洗售规则）是 IRS 规定：若在卖出证券前后各30天内（共61天窗口）买入"实质相同"的证券，则该亏损不得用于抵税。

## 核心要点
- 窗口：卖出日前30天 + 卖出日 + 卖出日后30天 = 61天
- "实质相同"包括：完全相同的股票/ETF，以及追踪同一指数的不同ETF（有争议）
- 跨账户有效：应税账户卖出，在 IRA/Roth IRA 内买回，仍触发 wash sale
- 触发后：亏损不消失，而是加到新买入资产的成本基础上（递延）
- 绕过方式：买入不同但相关的 ETF（如卖 SPY 买 VTI 更安全）

## 与其他概念的关系
- [[税损收割]]：税损收割操作的核心合规要求
- [[Roth-IRA]]：跨账户买卖同种资产仍触发，需特别注意

## 参考来源
- [[raw_material/投资策略建议]]
