---
title: Asset Location（资产位置优化）
category: 税务策略
tags: [资产配置, 税务优化, 账户选择, 税后收益]
source: "[[raw_material/税务优化/Asset-Location]]"
updated: 2026-04-16
status: draft
freshness: annual
---

## 定义
Asset Location（资产位置）是指将不同税收属性的资产，分配至最适合其税务特征的账户类型，以最大化税后整体收益。核心原则：高税负资产放税优账户，低税负资产放应税账户。

## 核心要点
- **应税账户（Taxable/Brokerage）**：持有低税负资产
  - 指数 ETF（低换手率，少量资本利得分配）
  - 长期持有股票（利用[[资本利得税]]长期优惠税率）
  - [[SGOV]] 等州税豁免债券
- **Traditional IRA / 401K（税前账户）**：持有高税负资产
  - 债券、债券基金（利息按普通收入税率）
  - REITs（分红按普通收入税率）
  - 高换手率主动基金
- **Roth IRA（税后账户）**：持有高增长资产
  - 小盘股/新兴市场 ETF
  - 高增长个股
  - [[杠杆ETF]]（增值完全免税）
- HSA 同 Roth，优先持有高增长资产

## 与其他概念的关系
- [[Roth-IRA]]：增值提取完全免税，最适合高增长资产的"永久庇护所"
- [[Traditional-IRA]]：提取按普通税率，高派息债券放此可延税
- [[HSA]]：三重税优，可按 Roth 策略配置高增长资产
- [[税损收割]]：仅在应税账户有意义，税优账户内无需操作
- [[资本利得税]]：合理的 Asset Location 可将大量收益转换为长期资本利得税率

## 参考来源
- [[raw_material/税务优化/Asset-Location]]
