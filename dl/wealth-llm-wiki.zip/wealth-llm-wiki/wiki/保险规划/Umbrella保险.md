---
title: Umbrella保险
category: 保险规划
tags: [保险规划, 伞形险, 诉讼保护, 资产保护, 高净值]
source: "[[raw_material/家庭财务基础/保险规划总纲]]"
updated: 2026-04-20
status: draft
freshness: volatile
---

## 定义

**Personal Umbrella Insurance**（个人伞形险）：在 auto、homeowners、renters 等底层保险的责任额度（liability）用尽后接力覆盖的超额责任险。保费极低、保障极高，是**高净值家庭资产保护的第一道屏障**。

## 核心要点

**典型触发场景**：
- 车祸撞人导致永久伤残
- 客人在你家受伤（泳池、蹦床、台阶）
- 宠物咬伤他人
- 青少年司机重大事故
- 诽谤 / 社交媒体言论（部分保单覆盖）

**经典算例**：
```
车险 bodily injury 上限 $300k
撞人导致永久伤残，对方索赔 $2M
→ 车险付 $300k，你自己付 $1.7M（被扣工资/资产/未来收入流）
→ 有 $2M Umbrella：保险全额覆盖，你出 $0
```

**底层保险要求**（Umbrella 才会接力）：
- Auto：通常要求 **250/500** bodily injury（$250k per person / $500k per accident）
- Homeowners：通常要求 **$300k liability**
- 若底层不够，Umbrella 公司拒赔或要求先补齐底层

**保额规则**：**保额 ≥ 你的净资产**

| 净资产 | 推荐 Umbrella 保额 |
|-------|------------------|
| < $100k | 暂不需要（资产少，诉讼不划算） |
| $100-500k | $500k |
| $500k-1M | $1M |
| $1-2M | $1-2M |
| $2M+ | $2-5M |

> 💡 **进阶规则**：保额 = 净资产 + 未来 10 年预期收入现值（保护未来收入不被扣押）

**保费极便宜**：
- $1M 保额：$200-500/年
- 每增 $1M：加 $100-200/年
- $5M 保额：通常 < $1,500/年
- **ROI 极高**（比任何其他保险都划算）

**必须买的人群**：
- 净资产 > $500k
- 有游泳池、蹦床、秋千（attractive nuisance）
- 养大型犬（pit bull、rottweiler、doberman 等）
- 家有**青少年司机**
- 出租房产（每一处房产都要覆盖）
- 公众人物 / 社交媒体活跃 / 经常招待客人
- 社区志愿者 / 业委会成员（可能因职务诉讼）

**何时可暂缓**：
- 资产很少（< $100k，自己可消化诉讼）
- 租房无宠物无高风险物
- 独身且社交很少

**购买策略**：
- **同公司捆绑**：从现有 auto/homeowners 公司加 Umbrella，通常有 multi-policy 折扣
- 如果底层保险跨公司，可向独立代理人咨询
- 主要供应商：GEICO、State Farm、Allstate、USAA（军属）、Chubb（高净值专用）

**注意事项**：
- **车辆要包含所有司机**（子女在外上学也要列入）
- **出租房要单独列出**（或用 Landlord Policy 代替）
- **商业活动通常不覆盖**（需 Commercial Umbrella）
- **故意行为不赔**（spite / malice / 犯罪）

## 与其他概念的关系

- [[保险优先级]]：第 2 层（资产保护）第 1 位
- [[净资产追踪]]：直接决定保额（保额 ≥ 净资产）
- [[Revocable-Living-Trust]]：Trust 持有资产也需 Umbrella 覆盖
- [[Own-Occupation失能险]]：失能险保收入，Umbrella 保资产
- [[FIRE运动]]：FIRE 达标者必须有 Umbrella 保护存量

## 参考来源

- [[raw_material/家庭财务基础/保险规划总纲]]
