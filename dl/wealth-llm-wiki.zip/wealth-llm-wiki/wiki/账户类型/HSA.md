---
title: HSA（健康储蓄账户）
category: 账户类型
tags: [健康储蓄, 三重税优, HDHP, 美国]
source: "[[raw_material/退休账户/HSA]]"
updated: 2026-04-16
status: draft
freshness: annual
---

## 定义
HSA（Health Savings Account）是与高免赔额健康保险（HDHP）配套的储蓄账户，享有供款抵税、增值免税、合格医疗支出提取免税的"三重税优"，被誉为隐藏的退休账户。

## 核心要点
- 2026年供款上限：个人 $4,400 / 家庭 $8,750（55岁以上各加 $1,000）
- 资格要求：必须参加 HDHP（2026 起点：个人 $1,650 / 家庭 $3,300）
- 三重税优：① 供款抵税（或税前扣除）② 投资增值免税 ③ 合格医疗提取免税
- 账户余额永久结转，无"不用则失"规则
- 65 岁后可用于任意用途（非医疗按普通所得税，类同 [[Traditional-IRA]]）；用于医疗仍免税
- 最优策略：现金支付医疗费用，保留收据，账户内投资增值，日后任意时间凭收据免税提取

## 与其他概念的关系
- [[Traditional-IRA]]：65 岁后 HSA 非医疗提取与 Traditional IRA 提取税务相同
- [[401K]]：HSA 可视为医疗版 401K，优先级应高于 after-tax 401K
- [[Asset-Location]]：HSA 适合持有高增长资产，因提取完全免税
- [[联邦所得税]]：HSA 供款同时降低 AGI，可减少 NIIT 和 AMT 暴露

## 参考来源
- [[raw_material/退休账户/HSA]]
