---
title: SGOV
category: 账户类型
tags: [ETF, 现金等价物, 州税豁免, 短期国债]
source: "[[raw_material/投资策略建议]]"
updated: 2026-04-16
status: stable
freshness: volatile
---

## 定义
SGOV 是 iShares 的0-3个月美国国债 ETF，是现金等价物，利息收入享受州税豁免（联邦税正常缴）。

## 核心要点
- 年化收益约 5.0-5.3%（随联邦基准利率浮动）
- 利息免加州等州税（T-bill 利息州税豁免）
- 税后实际收益约3.9-4.0%（按24%联邦税）
- 优于 HYSA（4%税前，缴加州税后仅约2.5%）
- 流动性高，T+1结算，适合停放短期闲置资金

## 与其他概念的关系
- [[ETF总览]]：SGOV 属于债券/货币市场 ETF 类别
- [[税损收割]]：SGOV 波动极小，几乎无税损收割机会

## 参考来源
- [[raw_material/投资策略建议]]
