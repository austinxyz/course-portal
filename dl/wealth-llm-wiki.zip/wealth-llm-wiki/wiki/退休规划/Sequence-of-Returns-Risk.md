---
title: Sequence-of-Returns-Risk
category: 退休规划
tags: [退休规划, 风险管理, 安全提取率]
source: "[[raw_material/退休规划/Sequence-of-Returns-Risk]]"
updated: 2026-04-16
status: draft
freshness: evergreen
---

## 定义

收益顺序风险（Sequence of Returns Risk）：即使长期平均年化回报相同，**退休提取期开局几年的回报顺序决定组合命运**。积累期顺序无所谓，提取期开局熊市可导致组合提前耗尽。

## 核心要点

- **为何致命**：提取固定金额 → 熊市卖出更多份额 → 本金永久损耗 → 复利反向加速
- **经典案例**：同等平均回报 7%，先好后坏 vs 先坏后好，30 年后差距可达组合全额耗尽 vs $800k+
- **红色警戒区（Retirement Red Zone）**：退休前后各 5 年是最危险的 10 年；第一年跌 15% + 提取 3.3%，30 年耗尽概率**提高 6 倍**
- **历史数据**：1926–2020 回测，最差起点（1965–66）SAFEMAX 仅 4.15%，最佳起点（1981–82）高达 10%+，相差 2.5 倍

**六大缓解策略**：

| 策略 | 核心做法 |
|------|---------|
| 现金缓冲 | 保留 1-3 年 SGOV/T-Bills，熊市不动股票 |
| Bond Tent | 退休前后降低股票比例至 40-50% |
| 动态提取 | 熊市主动减支出 10-20%（Guardrails） |
| 部分年金化 | 用年金固定基础支出，消除"必须卖"压力 |
| 延迟退休 | 多工作 1-2 年可能完全改变命运 |
| Rising Equity | 退休后反向增持股票（[[Bond-Tent]]） |

## 与其他概念的关系

- [[4%规则]]：SRR 是对 4% 规则平均回报假设的最大挑战
- [[Bucket-Strategy]]：最直接应对 SRR 的结构性工具
- [[Bond-Tent]]：退休前后降低股票敞口的系统性方法
- [[FIRE运动]]：早退休者退休期更长，SRR 风险显著放大
- [[Social-Security]]：SS 收入流可替代熊市卖股，直接缓解 SRR

## 参考来源

- [[raw_material/退休规划/Sequence-of-Returns-Risk]]
