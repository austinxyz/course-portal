---
title: 杠杆 ETF
category: 投资品种
tags: [杠杆ETF, TQQQ, 高风险, 衰减]
source: "[[raw_material/投资策略建议]]"
updated: 2026-04-16
status: stable
freshness: volatile
---

## 定义
杠杆 ETF 每日追踪标的指数的2倍或3倍涨跌。由于每日重置机制，长期持有存在"波动率衰减"（Volatility Decay），熊市和震荡市中损失远超预期。

## 核心要点
- 代表标的：TQQQ（3倍QQQ）、SOXL（3倍半导体）
- 适合短期趋势交易，不适合长期持有（除非牛市明确）
- 波动率衰减：指数震荡±10%时，3倍ETF净值持续下滑
- 强烈建议在 Roth IRA 内持有：若增值免税，若亏损无法税损收割（两者均适用）
- 仓位控制：总资产占比建议<5%

## 与其他概念的关系
- [[ETF总览]]：杠杆ETF 是 ETF 的高风险变种
- [[税损收割]]：Roth IRA 内持有则无法税损收割，应税账户内可操作
- [[Roth-IRA]]：杠杆ETF 的最优持有账户

## 参考来源
- [[raw_material/投资策略建议]]
