# Session 4 作业指南

> **目标：** 用今天演示的「三层 Skill 工程方法」，自己从零写一个 `/market-daily` Skill，每天一行命令生成你自己的市场日报。
>
> 核心体验和 Part B 一样：**分层 → 固化知识 → 测试**——只是把「热门赛道选股」换成「每日市场简报」。

---

## 步骤总览

| 步骤 | 内容 | 是否必须提交 |
|------|------|------------|
| 准备 | 跟着 `跟我做-提示词.md` 跑一遍 | — |
| Step 1 | 拆需求：写三个分层需求文件 | — |
| Step 2 | 确认 Python 层：验证 ticker_scan.py 能取到数据 | — |
| Step 3 | 写 LLM 层 Skill：把你的「市场判断框架」固化进去 | **是**（截图 skill 文件）|
| Step 4 | 加 Web Search 层：补实时新闻 | — |
| Step 5 | 测试：正常跑 + 边界 | **是**（截图日报输出）|
| 进阶 ★ | 加个股 / 换 A 股 / 建第二个 Skill | 否 |

> **动手前必须先跑一遍 `demo/跟我做-提示词.md`**（约 50 分钟）——把完整流水线和 /ticker-scan 的从零构建全部跑通，确认环境正常、三层方法理解了，再开始下面的步骤。

---

## 准备：跑通演示（必须先做）

在 Claude Code 打开 `stock-analysis-lite-main/`，照顺序跑完 `demo/跟我做-提示词.md` 的全部 12 步（第三段 /etf-analyze 加餐选做，推荐想分析 ETF 的同学跑）。

重点感受三件事：
- **第 7 步**：需求是怎么被拆成三个文件的（这套分法你马上要照着做）
- **第 9 步**：方法论的知识（赛道定义、打分规则）是怎么字面量写进 Skill 文件的
- **第 10 步**：生成完不直接信——拿需求文件当清单让 AI 自己对账补缺

跑完后，`.claude/commands/ticker-scan.md` 应该已经写好、`/ticker-scan` 能正常输出。

---

## Step 1：拆需求——写三个分层需求文件

> **这步的意义：** 先想清楚「市场日报」要做什么，再动手——和 ticker-scan 演示里的「阶段 01」完全一样的方法。

新建一个目录，或者继续在 `stock-analysis-lite-main/` 里操作。在 Claude Code 对话框里输入：

```
我要建一个 /market-daily skill，每天生成一份市场简报。
请把这个 skill 的所有需求拆成三类，保存为三个文件：

1. docs/req-mktdaily-python.md   — Python 层：需要稳定取数的部分（价格、涨跌幅、成交量等）
2. docs/req-mktdaily-llm.md      — LLM 层：需要自然语言解读、判断市场情绪、生成文字的部分
3. docs/req-mktdaily-websearch.md — Web search 层：需要今日新闻、美联储动态、经济数据的部分

日报要包含：
- 大盘涨跌（SPY / QQQ）
- VIX 恐慌指数及情绪解读
- 今日市场关键观察（2–3 条）
- 今日需要关注的风险点（1 条）
- 输出保存为 outputs/market/YYYY-MM-DD.md

每个文件只列「要做什么」，不写代码。
```

读完三个文件，自己想一想：**LLM 层的判断标准是什么？** 比如：
- VIX > 30 你会怎么说？VIX < 15 呢？
- SPY 跌 1.5% + QQQ 跌 2% 你会怎么描述市场情绪？
- 什么情况下会说"今日适合观望"？

**把你自己的判断规则补进 `docs/req-mktdaily-llm.md`**——这一步是让 Skill 变成你自己的系统，而不是通用系统。

---

## Step 2：确认 Python 层——验证 ticker_scan.py 能取到数据

> **这步的意义：** 像演示里的「阶段 01 验证」一样——先确认数据层能跑，再写上层逻辑。市场日报的 Python 层很简单，直接复用现有脚本就行。

在 Claude Code 里输入：

```
读 scripts/ticker_scan.py 和 docs/req-mktdaily-python.md，
确认：
1. 用 ticker_scan.py 取 SPY、QQQ、VIX 数据，能拿到哪些字段？
2. req-mktdaily-python.md 里列的需求，脚本已经覆盖了哪些？
3. 有哪些字段脚本给不了（如果有）？

验证方式：实际运行一次，让我看到 SPY 的输出样本。
```

运行：

```bash
python scripts/ticker_scan.py SPY --json
python scripts/ticker_scan.py QQQ --json
python scripts/ticker_scan.py "^VIX" --json
```

> ⚠️ VIX 必须写成 `^VIX`（带尖号并加引号）。直接传 `VIX` 会报 `insufficient price history`。

看到三个 JSON 输出即 Python 层确认完毕。如果某字段缺失，补一句：

```
请在 docs/req-mktdaily-python.md 里标注哪些字段脚本有、哪些缺，
缺的字段是否影响日报质量？如果影响，建议怎么补？
```

> **Python 层尽量复用**，不要为了作业专门写新脚本。日报需要的数据（价格 / 涨跌 / VIX 数值）ticker_scan.py 基本都能给。

---

## Step 3：写 LLM 层 Skill——把你的市场判断固化进去

> **这步是作业的核心。** 对应演示里的「阶段 02」——方法论的知识字面量写进 Skill，AI 按你定的框架走，不是乱猜。

在 Claude Code 里输入：

```
根据 docs/req-mktdaily-llm.md，生成 .claude/commands/market-daily.md：

- 角色：每日市场简报助手
- 数据来源：先调用 scripts/ticker_scan.py 分别取 SPY、QQQ、VIX 数据（JSON 格式），
  再基于数据做 LLM 解读
- 判断框架（按 req-mktdaily-llm.md 里我定义的规则来）：
    * VIX 分级解读：<15 低恐慌 / 15–25 正常 / 25–35 警戒 / >35 恐慌
    * 大盘涨跌解读：以 SPY 和 QQQ 同向 / 背离来判断情绪
    * 关键观察：从数据中找 2–3 条值得今日关注的信号
    * 风险提示：1 条今日需要警惕的情况
- 输出格式：Markdown，带标题分区，保存为 outputs/market/YYYY-MM-DD.md
- 无数据时（如周末、节假日）输出"今日市场休市"，不要报错

直接写入文件。
```

生成后，**先让 AI 对账**（和课上第 10 步同一招）：

```
逐条对照 docs/req-mktdaily-llm.md 和 .claude/commands/market-daily.md：
列一张对账表（✅/❌），缺的需求直接补进文件。
```

然后**自己读一遍 Skill 文件**，检查三件事：

1. **你的判断规则在里面了吗？** 比如你对 VIX 的解读、你对涨跌幅的语言描述标准——如果不在，补进去
2. **LLM 层和 Python 层有没有混在一起？** LLM 层应该只是「拿到数字 → 解读 → 生成文字」，不应该出现 Python 代码
3. **输出格式是你想要的吗？** 每天打开日报，结构是否清晰

不满意就直接说：

```
第三部分"关键观察"格式太死板，改成更像分析师风格的自然语言段落，不要用项目符号列表。
```

---

## Step 4：加 Web Search 层——补今日实时信息

> **这步把静态框架变成活的日报。** yfinance 给不了今天发生了什么——美联储说了什么、有没有重大财报、宏观数据出炉了没——这些靠 web search 补。

在 Claude Code 里输入：

```
根据 docs/req-mktdaily-websearch.md，在 market-daily.md 里加 web search 步骤：

在生成日报时，搜索今日：
1. 美联储最新表态或利率相关新闻
2. 标普 500 / 纳斯达克的主要驱动因素（今日是什么原因涨/跌）
3. 今日关键经济数据（如有）

把搜索结论整合进日报的「今日关键观察」段落，每条标注来源。
如果搜索无结果或网络不可用，写"暂无今日实时信息，仅基于量化数据"。

直接修改 market-daily.md 文件。
```

---

## Step 5：测试——正常跑 + 边界

**测试一：完整运行**

```
/market-daily
```

对照四个问题：
- 数据有没有取到（SPY / QQQ / VIX 数值都在）？
- VIX 解读符合你定义的分级标准吗？
- 「关键观察」是基于数据推出来的，不是乱写的？
- Web search 有实时内容，有来源？

输出保存到 `outputs/market/YYYY-MM-DD.md`。

**测试二：边界测试**

```
今天是周六，市场休市。请运行 /market-daily，看看会输出什么。
```

Skill 应该输出"今日市场休市"提示，而不是报错或乱跑。

**如果输出质量不够好：** 先改 `docs/req-mktdaily-llm.md` 里的判断规则，再让 Claude Code 重新生成 Skill，再测试——和演示里一样：**输入质量 > 提示词技巧**。

---

## 进阶（选做）

**选项 A：加入你关注的个股**

```
在 market-daily.md 里加一个「自选股状态」模块：
取以下 ticker 的今日价格和涨跌幅：[你的 ticker 列表，如 MRVL ASTS NVDA]
跟昨日收盘比，标注涨跌、是否创近 52 周新高。
```

**选项 B：换成 A 股版**

yfinance 支持 A 股代码（格式如 `600036.SS` `000858.SZ`），赛道和解读框架换成 A 股逻辑：

```
把 market-daily.md 的数据源改为 A 股：
取沪深 300（000300.SS）、创业板指（399006.SZ）、以及你关注的 2-3 支 A 股。
VIX 改用 A50 波动率指标作为情绪参考。
解读语言改为 A 股视角。
```

**选项 C：建第二个 Skill**

照同样的三层方法，为你自己的场景再建一个 Skill：

- `/sector-scan`：扫你自己定义的几个赛道（不一定是课上的七大赛道）
- `/earnings-watch`：追踪即将发布财报的公司
- 或者任何你觉得能用三层架构解决的重复分析任务

```
我要建一个 /[你起的名字] skill，功能是：[一句话描述]。
请帮我按三层架构（Python / LLM / Web Search）先写三个需求文件。
```

---

## 提交要求

发邮件至 **austin.aicourse@gmail.com**，主题必须是：**【S4 作业】+ 你的名字**

**三样都要：**

1. **`/market-daily` 输出的日报截图**——运行后生成的 `.md` 文件截图（`outputs/market/YYYY-MM-DD.md`），让我能看到数据 + 解读 + web search 结果。

2. **`.claude/commands/market-daily.md` 截图**——你的 Skill 文件全貌（或复制粘贴文本内容）。我会看：你的判断规则有没有真的固化进去，三层结构是否清晰。

3. **200 字心得**——课上演示的是选股系统，你做的是市场日报，方法一样。写下：
   - 你的「市场判断框架」是什么？你把哪些规则固化进了 LLM 层？
   - 哪一步最难？哪里 AI 给的结果让你觉得需要修改？
   - 如果你在用这套系统做真实投资决策，还会加什么？

（200 字以上，不设上限）

---

## 常见问题

**Q：我对美股不熟悉，可以换成其他内容吗？**

可以。日报不一定是股市——可以换成「每日加密货币简报」（BTC / ETH）、「每日宏观经济指标追踪」，或者任何有量化数据 + 需要文字解读的场景。换一下 ticker 和解读框架就行，三层方法完全相同。

**Q：`scripts/ticker_scan.py` 取 VIX 数据会有问题吗？**

VIX 在 yfinance 里的代码是 `^VIX`。如果 `ticker_scan.py` 直接传 `VIX` 报错，改传 `^VIX`。也可以在 Claude Code 里说："帮我确认 yfinance 取 VIX 数据的正确代码格式。"

**Q：我不知道怎么定义「判断规则」，感觉什么都是 AI 猜的。**

这是 Step 3 最重要的问题。先试着问自己：**"如果我每天早上看大盘，我会关注什么？我怎么判断今天要不要操作？"** 哪怕只有 3 条规则，也比没有规则强——AI 有框架才能稳定输出，没框架会每次答案不一样。

**Q：Web search 在我的 Claude Code 里用不了怎么办？**

跳过 Step 4，先让日报基于纯数据跑起来。提交时说明"web search 层未完成"——核心是 LLM 层的判断框架，这才是作业的重点。

**Q：Skill 文件写好了，但 `/market-daily` 跑出来格式很乱。**

在 chat 里直接补需求：

```
/market-daily 输出格式不够清晰，请修改 market-daily.md，
要求输出包含以下分区标题：
## 📊 今日大盘
## 😨 VIX 情绪
## 🔍 关键观察
## ⚠️ 今日风险提示

修改后重新生成日报。
```

**Q：完整 12 步跟我做太长了，能不能跳过直接做作业？**

强烈不建议。第二段（第 6–12 步）是核心——如果没有亲手跑过「备份清空 → 分层 → 写 Skill → 对账 → 测试」的完整流程，做作业时会不知道「分层文件」是什么，也不明白为什么要先写 req-python.md 再写 Skill。先跑一遍，再做自己的。第三段加餐可以跳过。
