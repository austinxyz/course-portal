# Follow Along · Session 4 Demo Prompts

> In class I'll type these prompts one at a time. **Copy and paste them in order** and you'll build the full stock-analysis system alongside me, then write a Skill from scratch.
> Three parts: **Part 1** run the full pipeline → **Part 2** write `/ticker-scan` from zero → **Part 3 (bonus)** adapt `stock-analyze` into `/etf-analyze`.
>
> **Before you start:**
> 1. Download `stock-analysis-lite-main.zip` from the course portal and unzip it locally
> 2. Open the unzipped `stock-analysis-lite-main/` folder in Claude Code
> 3. **Switch output language to English** — open `data/config.md` and change `lang: zh` to:
>    ```
>    lang: en
>    ```
>    (`/ticker-scan` reads this setting explicitly. The other three Skills have no language switch, but Claude follows your conversation language — prompt in English and you'll get English back. The methodology docs under `wiki/` are in Chinese; Claude reads them fine and still answers in English.)
> 4. Verify your setup — type this in Claude Code:
>    ```
>    List the skill files under .claude/commands/ and confirm scripts/ticker_scan.py exists.
>    ```
>    You should see 4 skill files + `ticker_scan.py` ✓
> 5. Install dependencies:
>    ```
>    Install the Python dependencies that scripts/ticker_scan.py needs.
>    ```

---

# Part 1 · See the Full Pipeline (run along, understand the end state)

> This part is "see the result first, learn the theory second" — run the complete system end to end. Ten minutes from sector scan to entry/exit decision.

## Step 1 · Scan for candidates

> 👉 **What this does**: Sweeps all seven structural sectors and outputs a candidate list with preliminary scores. Doing this by hand takes 2–3 hours; here it takes 2 minutes.

```
/ticker-scan optical
```

Look at the output: a candidate table with each stock's sector tag and the reason it made the cut.

> Other sectors you can try: `storage`, `satellite`, `grid`, `packaging`, `minerals`, `realestate`. No argument at all scans all seven.

---

## Step 2 · Fundamental analysis

> 👉 **What this does**: Scores the candidate on the BAIT four-dimension mispricing framework (Behavioral / Analytical / Informational / Technical). The core question is "why is the market wrong?" — weak signals get cut immediately so you don't waste time.

Use the first stock from Step 1's output (CRDO is the example here — swap in whatever candidate you got):

```
/stock-analyze CRDO
```

Look at the output: total score out of 12 plus a rating. Only 🔥 Strong Interest or ⭐ Watch Candidate is worth continuing with.

---

## Step 3 · Entry range

> 👉 **What this does**: Combines SEPA (timing confirmation) and Moneyball (risk/reward math) to give you a buy range and a stop loss. If R/R is below 2:1, you don't enter.

```
/stock-entry CRDO
```

Look at the output: Stage assessment, pivot point location, entry range, stop loss, R/R ratio.

---

## Step 4 · Record the buy, update positions

> 👉 **What this does**: Analysis isn't done until it's recorded. Note that this step needs no new Skill — plain natural language is enough.

```
Update positions: bought 20 shares of CRDO at $236.50
```

Look at the output: Claude edits `positions.md` directly, CRDO moves from Watch → Active, and max loss is calculated automatically.

---

## Step 5 · Exit logic

> 👉 **What this does**: The system reads the position you just recorded and gives a trim recommendation. Each step's output is the next step's input — no re-entering data.

```
/stock-exit CRDO
```

Look at the output: current price vs target 1 / target 2, stop-loss status, trim recommendation.

---

# Part 2 · Write /ticker-scan From Zero (the core of Skill engineering)

> The script layer (`scripts/ticker_scan.py`) is already written. Today we focus on one thing: how to turn methodology knowledge into a Skill that AI can execute.
> Six steps: **back up and clear → split the methodology → write the LLM layer → quality check → add Web Search → test**.

## Step 6 · Back up and clear ticker-scan

> 👉 **What this does**: Backs up the existing ticker-scan, then empties it — we're writing from scratch so you can see exactly how each line gets added.

```
Back up .claude/commands/ticker-scan.md as ticker-scan.md.bak, then empty the original file.
```

---

## Step 7 · Split the methodology into three requirement files

> 👉 **What this does**: Splits every requirement in the methodology into three categories, each in its own file. Not for tidiness — so every later step has a clear *input file*: validate Python against req-python, write the Skill against req-llm, add web search against req-websearch.

```
Read wiki/frameworks/hot-sector-method.md and split all requirements into
three categories, saved as three files:

1. docs/req-python.md    — Python script layer: parts that need reliable data
                            fetching and calculation (yfinance, script already written)
2. docs/req-llm.md       — LLM analysis layer: parts that need natural-language
                            judgment, scoring, and generated prose
3. docs/req-websearch.md — Web search layer: parts that need live news and
                            institutional activity

Each file should list only what needs to be done — no code.
```

---

## Step 8 · Verify the Python script covers the script-layer requirements

> 👉 **What this does**: Checks the existing script against `req-python.md` to confirm the fields line up. If they do, you don't touch the script and go straight to designing the LLM layer.

```
Read scripts/ticker_scan.py, scripts/ticker_scan_guide.md, and docs/req-python.md,
then confirm:
1. Which requirements in req-python.md does the script already cover?
2. What JSON fields does the script output?
3. Are there any fields req-python.md asks for that the script is missing?
```

---

## Step 9 · Write the Skill — LLM analysis layer

> 👉 **What this does**: Embeds the methodology knowledge (sector definitions, scoring rules) directly into the Skill file — the AI doesn't guess, it follows the framework. This is the single most important step in Skill engineering: expert knowledge frozen into a prompt.

```
Based on docs/req-llm.md and wiki/frameworks/hot-sector-method.md,
generate .claude/commands/ticker-scan.md:

- Role: a stock-selection assistant based on the hot-sector methodology
- Seven-sector context: write the sector definitions and each sector's
  representative tickers directly into the Skill
- Data source: first call scripts/ticker_scan.py for JSON (fields confirmed in
  the previous step), then make LLM judgments based on that JSON
- Support three parameter modes:
    * no argument / all → scan all seven sectors
    * sector name (e.g. optical) → scan only that sector
    * ticker (e.g. CRDO) → analyze that single stock directly
- Judgment logic: cover **every** requirement in docs/req-llm.md, organized
  around the methodology's three-stage funnel. Copy each stage's scoring
  criteria and promotion thresholds directly from the methodology — do not
  simplify or omit anything on your own
- Output format: a ranked summary table (with labels) + a rejection table
  (list why each one was cut) + 2–3 sentences of analysis per candidate.
  Keep the per-stage scoring work in the report — don't give only conclusions
- Save results to outputs/ticker-scan/{today's date}-{argument or all}.md
- On empty results, output "No qualifying candidates found in this scan.
  Suggested next catalyst to watch: [X]" — do not throw an error

Write the file directly.
```

Then test it with CRDO:

```
/ticker-scan CRDO
```

Four quick checks:
1. Are the seven sectors + representative tickers in the file?
2. Is the whole three-stage funnel there? (nine characteristics → six types × five formulas → five criteria)
3. Does the report include a rejection table and the per-stage scoring, not just final conclusions?
4. Is there an output file under `outputs/ticker-scan/`?

---

## Step 10 · Quality check — have the AI audit itself against the requirements

> 👉 **What this does**: When AI generates long files it often "grabs the big stuff and drops the small stuff," missing some requirements. Don't hunt for gaps by eye — hand the AI the requirements file as a checklist and have it reconcile line by line and fill what's missing. This trick works for any Skill.

```
Go through docs/req-llm.md and .claude/commands/ticker-scan.md line by line:

1. Build a reconciliation table: for each requirement in req-llm.md, is it
   covered in the Skill (✅/❌)?
2. For each ❌, explain what's missing
3. Add the missing requirements into ticker-scan.md — edit the file directly
```

Look at the output: only move on when the table is all ✅. If it filled gaps, run this same prompt again to double-check.

---

## Step 11 · Add the Web Search layer

> 👉 **What this does**: yfinance can't give you live news — institutional accumulation and order catalysts need web search. Add this layer and the Skill becomes three layers working together: Python supplies numbers, the LLM makes judgments, web search fills in live signals.

```
Based on docs/req-websearch.md, add a web search step to ticker-scan.md:

For each candidate that passes scoring, use web search to add live information
per the requirements in req-websearch.md. Add the search conclusion (1–2
sentences) into that stock's analysis paragraph, citing the source.
If the search returns nothing, write "No recent catalyst information available."

Edit the ticker-scan.md file directly.
```

---

## Step 12 · Test

> 👉 **What this does**: Two-part validation — first check the Skill's full output, then test the edge case (does it break when there are no candidates?).

**Validate the Skill output:**

```
/ticker-scan CRDO
```

Three checks:
- Did the table appear, with an analysis paragraph per stock?
- Is the scoring grounded in the nine characteristics, not made up?
- Do the analysis paragraphs contain live info from web search, with sources cited?

**Edge-case test:**

```
/ticker-scan nonexistent
```

See whether the AI returns a graceful message instead of an error.

---

# Part 3 · Bonus: Adapt stock-analyze into /etf-analyze

> A lot of you want to analyze ETFs. This part teaches the second way to build a Skill: **adapt an existing one**. You never write the second Skill from scratch.
> Three steps: **compare the differences → generate by reference → reconcile and test**.

## Step 13 · Requirements analysis — how ETFs differ from single stocks

> 👉 **What this does**: Before writing, work out which dimensions in `stock-analyze` don't hold for ETFs. Don't reason it out yourself — have the AI compare.

```
Read .claude/commands/stock-analyze.md and wiki/frameworks/hot-sector-method.md.
I want to build a skill for analyzing ETFs (sector ETFs like SOXX / SMH).

Build a comparison table: for each analysis dimension in stock-analyze, does it
apply to ETFs?
- Mark the applicable ones "keep"
- For the ones that don't apply, explain why and propose the ETF equivalent

Output only the comparison table for now — don't write any files.
```

Look at the output: BAIT / financials / share-structure should get replaced (holdings concentration, expense ratio, AUM, liquidity), while the SEPA technical layer stays.

---

## Step 14 · Generate /etf-analyze by reference

> 👉 **What this does**: Uses `stock-analyze` as a template to generate a new Skill. Notice how short the prompt is — the template already lives in the existing Skill. Adapting costs far less than writing from scratch.

```
Using .claude/commands/stock-analyze.md as a reference for structure and output
style, and following the comparison table above, generate
.claude/commands/etf-analyze.md:

- Data source unchanged: scripts/ticker_scan.py (yfinance supports ETFs) + web search
- ETF dimensions:
    * Holdings concentration: top 10 holdings weight, single-holding risk
    * Cost and liquidity: expense ratio, AUM, average daily volume
    * Sector thesis: which sector this ETF covers, judged against the
      seven-sector framework
    * ETF vs single stock: buying this ETF vs the strongest stock in the
      sector — when to pick which
- Keep the SEPA technical assessment (Stage / trend template as-is)
- Output rating: ✅ Worth allocating / 👀 Watch / ❌ Avoid, with a one-line reason
- Save results to outputs/etf-analyze/{today's date}-{ticker}.md

Write the file directly.
```

---

## Step 15 · Quality check + test

> 👉 **What this does**: Same rule as always — don't trust the output, reconcile it, then test for real.

**Reconcile:**

```
Go through the comparison table above and .claude/commands/etf-analyze.md line
by line: did every "keep" and "replace" dimension make it into the Skill?
Build a ✅/❌ reconciliation table and add anything missing directly to the file.
```

**Test (feel free to swap in an ETF you actually follow):**

```
/etf-analyze SOXX
```

Three checks:
- Did the ETF dimensions appear? (top-10 concentration / expense ratio / AUM)
- Is there an "ETF vs single stock" comparison paragraph with a concrete recommendation?
- Is the SEPA technical layer still there, with a working Stage assessment?

---

# ✅ Definition of Done

- [ ] The req-llm.md reconciliation table is all ✅ (Step 10 quality check passed)
- [ ] `/ticker-scan` outputs a ranked summary table + rejection table + per-stock analysis
- [ ] The full three-stage funnel is present: nine characteristics → six types × five formulas → five criteria
- [ ] Analysis paragraphs include live web-search information
- [ ] Empty sectors produce a graceful message, not an error
- [ ] `.claude/commands/ticker-scan.md` is 120–200 lines and shows all three layers (Python data / LLM judgment / Web Search)
- [ ] (Bonus) `/etf-analyze` outputs ETF-specific analysis + an ETF vs single-stock recommendation
