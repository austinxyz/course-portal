# Session 4 Homework Guide

> **Goal:** Use the three-layer Skill engineering method from today's demo to write your own `/market-daily` Skill from scratch — one command, one daily market briefing.
>
> The core experience is the same as Part B: **split into layers → freeze your knowledge → test**. We're just swapping "hot-sector stock selection" for "daily market briefing."

---

## Overview

| Step | What | Required for submission |
|------|------|------------------------|
| Prep | Run through `follow-along-prompts-en.md` once | — |
| Step 1 | Split requirements: write three layered requirement files | — |
| Step 2 | Confirm the Python layer: verify `ticker_scan.py` fetches data | — |
| Step 3 | Write the LLM-layer Skill: freeze your market judgment framework into it | **Yes** (screenshot of the skill file) |
| Step 4 | Add the Web Search layer: pull in live news | — |
| Step 5 | Test: normal run + edge case | **Yes** (screenshot of the briefing output) |
| Bonus ★ | Add single stocks / switch markets / build a second Skill | No |

> **Before you start, you must run through `demo/follow-along-prompts-en.md` once** (about 50 minutes) — get the full pipeline and the from-scratch `/ticker-scan` build working end to end. Confirm your environment works and you understand the three-layer method before starting the steps below.

---

## Prep: Get the demo running (do this first)

Open `stock-analysis-lite-main/` in Claude Code and work through all 12 steps of `demo/follow-along-prompts-en.md` in order. (Part 3, the `/etf-analyze` bonus, is optional — recommended if you want to analyze ETFs.)

**Set your output language first:** open `data/config.md` and change `lang: zh` to `lang: en`.

Three things to pay attention to:
- **Step 7**: how the requirements get split into three files (you're about to do exactly this yourself)
- **Step 9**: how the methodology knowledge (sector definitions, scoring rules) gets written literally into the Skill file
- **Step 10**: don't trust the output — use the requirements file as a checklist and have the AI reconcile and fill gaps

When you're done, `.claude/commands/ticker-scan.md` should be written and `/ticker-scan` should produce normal output.

---

## Step 1: Split the requirements — write three layered requirement files

> **Why this matters:** Work out what a "market briefing" needs to do *before* you start building — exactly the same method as Stage 01 in the ticker-scan demo.

Create a new directory, or keep working inside `stock-analysis-lite-main/`. Type this into Claude Code:

```
I want to build a /market-daily skill that generates a daily market briefing.
Split all the requirements for this skill into three categories, saved as
three files:

1. docs/req-mktdaily-python.md   — Python layer: parts that need reliable data
                                    fetching (price, % change, volume, etc.)
2. docs/req-mktdaily-llm.md      — LLM layer: parts that need natural-language
                                    interpretation, market sentiment judgment,
                                    and generated prose
3. docs/req-mktdaily-websearch.md — Web search layer: parts that need today's
                                    news, Fed developments, and economic data

The briefing should include:
- Index moves (SPY / QQQ)
- The VIX fear index and a sentiment read
- 2–3 key market observations for today
- 1 risk to watch today
- Output saved to outputs/market/YYYY-MM-DD.md

Each file should list only what needs to be done — no code.
```

Read the three files, then ask yourself: **what are the LLM layer's judgment criteria?** For example:

- What would you say if VIX > 30? What about VIX < 15?
- If SPY is down 1.5% and QQQ is down 2%, how would you describe market sentiment?
- Under what conditions would you say "today is a day to stay on the sidelines"?

**Add your own judgment rules into `docs/req-mktdaily-llm.md`** — this is the step that turns the Skill into *your* system rather than a generic one.

---

## Step 2: Confirm the Python layer — verify `ticker_scan.py` fetches data

> **Why this matters:** Just like Stage 01 validation in the demo — confirm the data layer works before writing logic on top of it. The Python layer for a market briefing is simple: reuse the existing script.

Type this into Claude Code:

```
Read scripts/ticker_scan.py and docs/req-mktdaily-python.md, then confirm:
1. If I pull SPY, QQQ, and VIX data with ticker_scan.py, which fields do I get?
2. Which requirements listed in req-mktdaily-python.md does the script already cover?
3. Are there any fields the script can't provide?

To verify: actually run it once and show me a sample of the SPY output.
```

Run:

```bash
python scripts/ticker_scan.py SPY --json
python scripts/ticker_scan.py QQQ --json
python scripts/ticker_scan.py "^VIX" --json
```

Three JSON outputs means the Python layer is confirmed. If a field is missing, add:

```
In docs/req-mktdaily-python.md, mark which fields the script provides and which
are missing. Do the missing fields affect briefing quality? If so, how would
you suggest filling the gap?
```

> **Reuse the Python layer as much as possible** — don't write a new script just for the homework. The data a briefing needs (price / % change / VIX level) is almost entirely available from `ticker_scan.py`.

---

## Step 3: Write the LLM-layer Skill — freeze your market judgment into it

> **This is the heart of the assignment.** It maps to Stage 02 in the demo — the methodology knowledge gets written literally into the Skill, so the AI follows the framework you defined instead of guessing.

Type this into Claude Code:

```
Based on docs/req-mktdaily-llm.md, generate .claude/commands/market-daily.md:

- Role: daily market briefing assistant
- Data source: first call scripts/ticker_scan.py to pull SPY, QQQ, and VIX data
  separately (JSON format), then interpret that data with the LLM
- Judgment framework (follow the rules I defined in req-mktdaily-llm.md):
    * VIX tiered interpretation: <15 low fear / 15–25 normal / 25–35 caution / >35 fear
    * Index interpretation: judge sentiment by whether SPY and QQQ move together
      or diverge
    * Key observations: find 2–3 signals from the data worth noting today
    * Risk note: 1 situation to be careful about today
- Output format: Markdown with section headings, saved to outputs/market/YYYY-MM-DD.md
- When there's no data (weekends, holidays), output "Market closed today" —
  do not throw an error

Write the file directly.
```

Once it's generated, **have the AI reconcile first** (the same trick as Step 10 in class):

```
Go through docs/req-mktdaily-llm.md and .claude/commands/market-daily.md line by
line: build a ✅/❌ reconciliation table and add any missing requirements directly
to the file.
```

Then **read the Skill file yourself** and check three things:

1. **Are your judgment rules actually in there?** Your VIX interpretation, your standards for describing moves — if they're missing, add them
2. **Are the LLM and Python layers mixed together?** The LLM layer should only be "take the numbers → interpret → generate prose." No Python code should appear
3. **Is the output format what you want?** When you open the briefing each day, is the structure clear?

If you're not happy with it, just say so:

```
The "key observations" section is too rigid. Rewrite it as flowing
analyst-style prose instead of a bulleted list.
```

---

## Step 4: Add the Web Search layer — pull in today's live information

> **This turns a static framework into a living briefing.** yfinance can't tell you what happened today — what the Fed said, whether there were major earnings, whether macro data landed. Web search fills that in.

Type this into Claude Code:

```
Based on docs/req-mktdaily-websearch.md, add a web search step to market-daily.md:

When generating the briefing, search for today's:
1. Latest Fed commentary or rate-related news
2. Main drivers of the S&P 500 / Nasdaq (why did they move today?)
3. Key economic data released today (if any)

Integrate the search conclusions into the "key observations" section of the
briefing, citing a source for each.
If the search returns nothing or the network is unavailable, write "No live
information available today; based on quantitative data only."

Edit the market-daily.md file directly.
```

---

## Step 5: Test — normal run + edge case

**Test 1: full run**

```
/market-daily
```

Four checks:
- Did the data come through (SPY / QQQ / VIX values all present)?
- Does the VIX interpretation match the tiers you defined?
- Are the key observations derived from the data, not invented?
- Does web search content appear, with sources?

Output is saved to `outputs/market/YYYY-MM-DD.md`.

**Test 2: edge case**

```
Today is Saturday and the market is closed. Run /market-daily and show me
what it outputs.
```

The Skill should output a "market closed today" message rather than erroring or producing nonsense.

**If the output quality isn't good enough:** change the judgment rules in `docs/req-mktdaily-llm.md` first, then have Claude Code regenerate the Skill, then test again — same as in the demo: **input quality beats prompt tricks**.

---

## Bonus (optional)

**Option A: add stocks you follow**

```
Add a "watchlist status" module to market-daily.md:
Pull today's price and % change for these tickers: [your list, e.g. MRVL ASTS NVDA]
Compare against yesterday's close, and flag gains/losses and any new 52-week highs.
```

**Option B: switch to a different market**

yfinance supports non-US tickers (e.g. `600036.SS` and `000858.SZ` for China A-shares, `0700.HK` for Hong Kong). Swap in your market's indices and interpretation framework:

```
Change market-daily.md's data source to the [your market] market:
Pull [your market's main index and 2-3 stocks you follow].
Replace VIX with an appropriate volatility indicator for that market.
Adjust the interpretation to that market's perspective.
```

**Option C: build a second Skill**

Use the same three-layer method to build another Skill for your own use case:

- `/sector-scan`: scan sectors you define yourself (not necessarily the seven from class)
- `/earnings-watch`: track companies with upcoming earnings
- Or any repetitive analysis task you think the three-layer architecture could solve

```
I want to build a /[your name] skill that does: [one-line description].
Please write three requirement files first, following the three-layer
architecture (Python / LLM / Web Search).
```

---

## Submission

Email **austin.aicourse@gmail.com** with the subject line: **[S4 Homework] + your name**

**All three items required:**

1. **Screenshot of the `/market-daily` output** — the generated `.md` file (`outputs/market/YYYY-MM-DD.md`), showing the data, your interpretation, and the web search results.

2. **Screenshot of `.claude/commands/market-daily.md`** — your full Skill file (or paste the text). I'll be looking at whether your judgment rules actually made it in, and whether the three-layer structure is clear.

3. **A ~200-word reflection** — the demo was a stock-selection system and yours is a market briefing, but the method is identical. Write about:
   - What is *your* market judgment framework? Which rules did you freeze into the LLM layer?
   - Which step was hardest? Where did the AI's output need correcting?
   - If you were using this system for real investment decisions, what else would you add?

(200 words minimum, no upper limit)

---

## FAQ

**Q: I'm not familiar with US markets. Can I do something else?**

Yes. The briefing doesn't have to be about stocks — it could be a daily crypto briefing (BTC / ETH), a daily macro indicator tracker, or any scenario with quantitative data that needs written interpretation. Swap the tickers and the interpretation framework; the three-layer method is exactly the same.

**Q: Will `scripts/ticker_scan.py` have trouble pulling VIX data?**

VIX's yfinance symbol is `^VIX`. If passing `VIX` directly errors out, use `^VIX` instead. You can also ask in Claude Code: "Confirm the correct symbol format for pulling VIX data from yfinance."

**Q: I don't know how to define "judgment rules" — it feels like the AI is guessing everything.**

This is the most important question in Step 3. Start by asking yourself: **"When I look at the market each morning, what do I actually pay attention to? How do I decide whether to trade today?"** Even three rules beat no rules — with a framework the AI produces stable output; without one, you get a different answer every time.

**Q: Web search doesn't work in my Claude Code. What now?**

Skip Step 4 and get the briefing running on pure data first. Note "web search layer not completed" in your submission — the core of this assignment is the LLM layer's judgment framework, and that's what's being evaluated.

**Q: The Skill file is written but `/market-daily` output is messy.**

Just add the requirement in chat:

```
The /market-daily output isn't clear enough. Modify market-daily.md so the
output includes these section headings:
## 📊 Today's Market
## 😨 VIX Sentiment
## 🔍 Key Observations
## ⚠️ Today's Risk

Then regenerate the briefing.
```

**Q: All 12 follow-along steps are too long. Can I skip straight to the homework?**

Strongly discouraged. Part 2 (steps 6–12) is the core — if you haven't personally run through "back up and clear → split layers → write Skill → reconcile → test," you won't know what a "layered requirement file" is when you do the homework, and you won't understand why `req-python.md` gets written before the Skill. Run it once, then build your own. Part 3 (the bonus) can be skipped.
